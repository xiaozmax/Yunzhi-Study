-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: yunzhi-study
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `fa_admin`
--

DROP TABLE IF EXISTS `fa_admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(20) DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) DEFAULT '' COMMENT '昵称',
  `password` varchar(32) DEFAULT '' COMMENT '密码',
  `salt` varchar(30) DEFAULT '' COMMENT '密码盐',
  `avatar` varchar(255) DEFAULT '' COMMENT '头像',
  `email` varchar(100) DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机号码',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `logintime` bigint(16) DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) DEFAULT NULL COMMENT '登录IP',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `token` varchar(59) DEFAULT '' COMMENT 'Session标识',
  `status` varchar(30) NOT NULL DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_admin`
--

LOCK TABLES `fa_admin` WRITE;
/*!40000 ALTER TABLE `fa_admin` DISABLE KEYS */;
INSERT INTO `fa_admin` VALUES (1,'admin','Admin','a48e3752c9dde682b8cbee0db6814864','967bee','http://wuliji01.xiaozmax.top:6789/assets/img/avatar.png','admin@admin.com','',0,1722039352,'192.168.142.1',1491635035,1722039352,'a1af9d91-fc79-4066-aafe-098ae92619ea','normal');
/*!40000 ALTER TABLE `fa_admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_admin_log`
--

DROP TABLE IF EXISTS `fa_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_admin_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `username` varchar(30) DEFAULT '' COMMENT '管理员名字',
  `url` varchar(1500) DEFAULT '' COMMENT '操作页面',
  `title` varchar(100) DEFAULT '' COMMENT '日志标题',
  `content` longtext NOT NULL COMMENT '内容',
  `ip` varchar(50) DEFAULT '' COMMENT 'IP',
  `useragent` varchar(255) DEFAULT '' COMMENT 'User-Agent',
  `createtime` bigint(16) DEFAULT NULL COMMENT '操作时间',
  PRIMARY KEY (`id`),
  KEY `name` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_admin_log`
--

LOCK TABLES `fa_admin_log` WRITE;
/*!40000 ALTER TABLE `fa_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_area`
--

DROP TABLE IF EXISTS `fa_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_area` (
  `id` int(10) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `pid` int(10) DEFAULT NULL COMMENT '父id',
  `shortname` varchar(100) DEFAULT NULL COMMENT '简称',
  `name` varchar(100) DEFAULT NULL COMMENT '名称',
  `mergename` varchar(255) DEFAULT NULL COMMENT '全称',
  `level` tinyint(4) DEFAULT NULL COMMENT '层级:1=省,2=市,3=区/县',
  `pinyin` varchar(100) DEFAULT NULL COMMENT '拼音',
  `code` varchar(100) DEFAULT NULL COMMENT '长途区号',
  `zip` varchar(100) DEFAULT NULL COMMENT '邮编',
  `first` varchar(50) DEFAULT NULL COMMENT '首字母',
  `lng` varchar(100) DEFAULT NULL COMMENT '经度',
  `lat` varchar(100) DEFAULT NULL COMMENT '纬度',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_area`
--

LOCK TABLES `fa_area` WRITE;
/*!40000 ALTER TABLE `fa_area` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_area` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_article`
--

DROP TABLE IF EXISTS `fa_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL COMMENT '分类ID',
  `title` text NOT NULL COMMENT '文章标题',
  `content` text NOT NULL COMMENT '文章内容（HTML）',
  `weight` int(11) NOT NULL COMMENT '权重',
  `isshow` tinyint(1) NOT NULL COMMENT '是否展示',
  `showedtimes` int(11) NOT NULL DEFAULT '0' COMMENT '点击次数',
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_article`
--

LOCK TABLES `fa_article` WRITE;
/*!40000 ALTER TABLE `fa_article` DISABLE KEYS */;
INSERT INTO `fa_article` VALUES (4,14,'借用工具辅助程序语言学习','<p><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px; color: #000000; font-family: 微软雅黑;\">一、本节课教学目标：</span><br/><span style=\"color: #000000; font-family: 微软雅黑;\">　　1、通过实际案例引入计算机程序设计解决问题的重要性</span><br/><span style=\"color: #000000; font-family: 微软雅黑;\">　　2、在具体程序体验过程中学习使用pythontutor平台，体会程序代码运行可视化。</span></p><p><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px; color: #000000; font-family: 微软雅黑;\">二、学习课件</span></p><p><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/2b6420feee54317d87962fb3f53aaa0e.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/37fd3c824cd338329d9a58f798b7febb.png\" style=\"width: 470.885px;\"/></p><p><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/f880a05282bd0243988628c2c0f33d51.png\" style=\"width: 470.885px;\"/><br/></p><p><br/></p><p><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/f3ec3a7b401fae04b6521ebcef94710b.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/0dc9c68ddcfe8898797858f772edc622.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/6fe9d9dd6f68fa378fee46777820859e.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/ff3e019a71c5f5b13d15a62bb7149123.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/6154f502e86e47a1bd28e608128037bc.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/4c5ad7186d0e94a32037cb7ae292c919.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/e9aa08958cbe8e3bf083aceeae3f0f45.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/e5d51126cd40f9eec6262ada4c71cbec.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/38f6b3372dffb0cf18caa5d72d6e89d4.png\" style=\"width: 470.885px;\"/>&nbsp;<span style=\"color: #000000; font-family: 微软雅黑;\">约瑟夫问题（k=2）</span><span style=\"color: #000000; font-family: 微软雅黑;\">见视频&nbsp;&nbsp;</span><a href=\"https://www.bilibili.com/video/BV1KM4y1V7tQ/?t=17&spm_id_from=333.1350.jump_directly&vd_source=f79eae2c01791c62f8df93dbcbd3f903\" style=\"background-color: rgb(255, 255, 255);\">你应该站在哪个位置，才能活到最后？</a></p><p><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px; color: #000000; font-family: 微软雅黑;\">三、作业提交说明</span><br/><span style=\"color: #000000; font-family: 微软雅黑;\">　　要求：打开</span><a href=\"https://pythontutor.com/\" target=\"_blank\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit; font-family: 微软雅黑;\">pythontutor.com</a><span style=\"color: #000000; font-family: 微软雅黑;\">，体验代码的执行过程可视化，截图运行过程和结果，标出不懂的语句（必做），根据运行结果请你改编刘谦的春晚魔术，你会如何改？（选做）</span><br/><span style=\"color: #000000; font-family: 微软雅黑;\">　　说明：1.文件名：登录号+姓名.png。</span><br/><span style=\"color: #000000; font-family: 微软雅黑;\">　　　　　2.通过云课堂提交作业</span><br/></p>',5,1,0),(5,14,'运用顺序结构描述问题求解过程--爬取天气网页上元素','<p class=\"stylefont\" style=\"text-align:left;margin-bottom: 5px; padding: 0px; color: rgb(0, 0, 0); background: inherit; line-height: 24px; font-family: 微软雅黑;\"><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px;\">一、本节课教学目标：</span><br/>　　1、能通过解决天气网页元素的爬取问题，体验顺序结构程序设计的执行过程，掌握程序调试与运行的方法。<br/>　　2、能在解决问题的过程中利用工具辅助理解Python程序。　　<br/></p><hr/><p class=\"stylefont\" style=\"text-align: center; margin-bottom: 5px; padding: 0px; color: rgb(0, 0, 0); background: inherit; line-height: 24px; font-family: 微软雅黑;\"><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px;\"><img src=\"http://10.0.0.36/uploads/20240322/df3e567d6f16d040326c7a0ea29a4f41.gif\" alt=\"spacer.gif\"/></span></p><p class=\"stylefont\" style=\"text-align:left;margin-bottom: 5px; padding: 0px; color: rgb(0, 0, 0); background: inherit; line-height: 24px; font-family: 微软雅黑;\"><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px;\">二、学习课件</span><br/></p><p style=\"text-align:center\"><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px;\"><video class=\"edui-upload-video  vjs-default-skin   video-js\" controls=\"\" preload=\"none\" width=\"1092\" height=\"614\" src=\"http://10.0.0.36/uploads/20240322/a5b9072af97a846e2e23f9a472c1ca21.mp4\"><source src=\"http://10.0.0.36/uploads/20240322/a5b9072af97a846e2e23f9a472c1ca21.mp4\" type=\"video/mp4\"/></video></span></p><p class=\"dl\" style=\"margin-bottom: 5px; padding: 0px; color: rgb(0, 0, 0); background: inherit; line-height: 24px; font-size: 12pt; font-family: 瀹嬩綋; text-align: -webkit-center;\"><a href=\"http://192.168.9.252/topics/shipinzhongxin/program01/program01.html\" target=\"_blank\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit;\"></a></p><p><span class=\"edui-editor-imagescale-hand0\" style=\"box-sizing: border-box; position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; background-color: #3C9DD0; cursor: nw-resize; top: 0px; margin-top: -4px; left: 0px; margin-left: -4px; color: #333333; font-family: &quot;Source Sans Pro&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;\"></span><span class=\"edui-editor-imagescale-hand1\" style=\"box-sizing: border-box; position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; background-color: #3C9DD0; cursor: n-resize; top: 0px; margin-top: -4px; left: 337px; margin-left: -4px; color: #333333; font-family: &quot;Source Sans Pro&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;\"></span><span class=\"edui-editor-imagescale-hand2\" style=\"box-sizing: border-box; position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; background-color: #3C9DD0; cursor: ne-resize; top: 0px; margin-top: -4px; left: 674px; margin-left: -3px; color: #333333; font-family: &quot;Source Sans Pro&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;\"></span><span class=\"edui-editor-imagescale-hand3\" style=\"box-sizing: border-box; position: absolute; width: 6px; height: 6px; overflow: hidden; font-size: 0px; display: block; background-color: #3C9DD0; cursor: w-resize; top: 145.5px; margin-top: -4px; left: 0px; margin-left: -4px; color: #333333; font-family: &quot;Source Sans Pro&quot;, &quot;Helvetica Neue&quot;, Helvetica, Arial, sans-serif;\"></span></p><p><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/55a585da990b90f6d816d689e488af06.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/77582f29186d9c554a0808b5581d78a4.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/7c9008e18045e5b9d6d3984d28cf6285.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/a9f198896bc101b825ac63a9de3d879c.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/29c28b5240d069defaa9ba2816cefed7.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/d5a4582608bb4d35897a1fa16015bd3b.png\" style=\"width: 470.885px;\"/><img src=\"http://wuliji01.xiaozmax.top:6789/uploads/20240322/b069c54d205bd5f986b420179aa15d63.png\" style=\"width: 470.885px;\"/></p><p class=\"stylefont\" style=\"text-align:left;margin-bottom: 5px; padding: 0px; color: rgb(0, 0, 0); background: inherit; line-height: 24px; font-family: 微软雅黑;\"><span class=\"stylefontS\" style=\"font-weight: 800; line-height: 28px; font-size: 16px;\">三、作业提交说明</span><br/>　　需要访问的网址列表：<br/>　　　　天气网：<a href=\"https://lishi.tianqi.com/\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit;\">lishi.tianqi.com</a>【如果出现404可换网站尝试】<br/>　　　　豆瓣网：<a href=\"https://www.douban.com/\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit;\">www.douban.com</a><br/>　　　　豆果网：<a href=\"https://www.douguo.com/\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit;\">www.douguo.com</a><br/>　　需要用到的代码半成品请下载：<br/>　　　　天气范例：<a href=\"http://192.168.9.252/topics/zyxz/dodown.jsp?x=xuean/new1/pic/weather_01.py\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit;\">weather_01.py</a><br/>　　　　豆瓣范例：<a href=\"http://192.168.9.252/topics/zyxz/dodown.jsp?x=xuean/new1/pic/douban_01.py\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit;\">douban_01.py</a><br/>　　　　豆果范例：<a href=\"http://192.168.9.252/topics/zyxz/dodown.jsp?x=xuean/new1/pic/douguo_01.py\" style=\"color: rgb(7, 81, 129); background-image: inherit; background-position: inherit; background-size: inherit; background-repeat: inherit; background-attachment: inherit; background-origin: inherit; background-clip: inherit;\">douguo_01.py</a><br/>　　要求：提交程序代码<br/>　　说明：1.文件名：登录号+姓名.py。<br/>　　　　　2.通过云课堂提交作业</p>',10,1,2),(6,15,'video','<p><span style=\"font-size: 20px;\">本文为视频测试文章</span></p><p><span style=\"font-size: 20px;\"><strong>以下为视频</strong></span></p><p><video class=\"edui-upload-video  vjs-default-skin      video-js\" controls=\"\" preload=\"none\" width=\"100%\" height=\"100%\" src=\"http://10.0.0.36/uploads/20240322/a5b9072af97a846e2e23f9a472c1ca21.mp4\"><source src=\"http://10.0.0.36/uploads/20240322/a5b9072af97a846e2e23f9a472c1ca21.mp4\" type=\"video/mp4\"/></video></p><p><span style=\"font-size: 36px;\">然后没了</span></p>',0,1,0),(7,15,'file','<p><span style=\"font-size: 24px;\">此为附件测试</span></p><p style=\"line-height: 16px;\"><img style=\"vertical-align: middle; margin-right: 2px;\" src=\"/assets/addons/ueditor/dialogs/attachment/fileTypeImages/icon_txt.gif\"/><a style=\"color: rgb(0, 102, 204); text-decoration: underline; font-size: 16px;\" href=\"http://10.0.0.36/uploads/20240322/705af6d24089d3df614daac19d948550.xlsx\" title=\"705af6d24089d3df614daac19d948550.xlsx\"><span style=\"font-size: 16px;\">705af6d24089d3df614daac19d948550.xlsx</span></a></p><p><span style=\"font-size: 24px;\">没了</span><br/></p>',0,1,0),(25,16,'HTML5 教程_w3cschool','<p><a href=\"https://www.w3cschool.cn/html5/\">HTML5 教程_w3cschool</a></p>',1,1,4),(26,17,'JavaScript 教程_w3cschool','<p><a href=\"https://www.w3cschool.cn/javascript/\">JavaScript 教程_w3cschool</a></p>',999,1,4),(32,18,'约瑟夫环','<div><strong><span style=\"font-size: 36px;\">约瑟夫环问题教学</span></strong></div><div class=\"container\"><h2>问题背景</h2><p>约瑟夫环问题是一个古老而著名的数学问题，它源自于一个历史故事。据说在罗马帝国时期，犹太历史学家约瑟夫和他的39个战友被罗马军队围困在洞中，他们决定集体自杀，但不打算向罗马人投降。他们围成一个圈，从第一个人开始，每数到第七个人就自杀，直到所有人都自杀为止。约瑟夫不想死，所以他计算了应该站在哪个位置，从而成为了最后一个自杀的人，并最终向罗马人投降。</p><h2>问题定义</h2><p>在数学和计算机科学中，约瑟夫环问题可以这样定义：设有编号为1到n的n个人围坐一圈，从第k个人开始报数，数到m的那个人出列，然后从下一个人重新开始报数，数到m的人再次出列，如此循环，直到所有人都出列。我们要找出最后出列的人的编号。</p><h2>解决方法</h2><p>约瑟夫环问题可以通过递归或迭代的方法来解决。这里我们介绍一种简单的迭代方法。我们可以模拟这个过程，但这种方法在人数很多时效率不高。更高效的方法是通过数学公式直接计算出最后胜利者的位置。</p><h2>示例代码</h2><p>下面是一个Python代码示例，它使用迭代方法来解决约瑟夫环问题：</p><pre class=\"brush:python;toolbar:false;\">def&nbsp;josephus_problem(n,&nbsp;k,&nbsp;m):\r\n&nbsp;&nbsp;&nbsp;&nbsp;&quot;&quot;&quot;\r\n&nbsp;&nbsp;&nbsp;&nbsp;解决约瑟夫环问题，返回最后胜利者的初始位置\r\n\r\n&nbsp;&nbsp;&nbsp;&nbsp;:param&nbsp;n:&nbsp;人数\r\n&nbsp;&nbsp;&nbsp;&nbsp;:param&nbsp;k:&nbsp;从第k个人开始报数\r\n&nbsp;&nbsp;&nbsp;&nbsp;:param&nbsp;m:&nbsp;数到m的人出列\r\n&nbsp;&nbsp;&nbsp;&nbsp;:return:&nbsp;最后胜利者的初始位置\r\n&nbsp;&nbsp;&nbsp;&nbsp;&quot;&quot;&quot;\r\n&nbsp;&nbsp;&nbsp;&nbsp;winner&nbsp;=&nbsp;0\r\n&nbsp;&nbsp;&nbsp;&nbsp;for&nbsp;i&nbsp;in&nbsp;range(1,&nbsp;n&nbsp;+&nbsp;1):\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;winner&nbsp;=&nbsp;(winner&nbsp;+&nbsp;k&nbsp;-&nbsp;1)&nbsp;%&nbsp;i&nbsp;+&nbsp;1\r\n&nbsp;&nbsp;&nbsp;&nbsp;return&nbsp;winner\r\n\r\n#&nbsp;示例：30个人，从第1个人开始报数，数到3的人出列\r\nn&nbsp;=&nbsp;30\r\nk&nbsp;=&nbsp;1\r\nm&nbsp;=&nbsp;3\r\nprint(josephus_problem(n,&nbsp;k,&nbsp;m))</pre><h2>数学公式</h2><p>对于约瑟夫环问题，存在一个数学公式可以直接计算出最后胜利者的位置。这个公式是：</p><pre>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;josephus(n,&nbsp;m)&nbsp;=&nbsp;(josephus(n&nbsp;-&nbsp;1,&nbsp;m)&nbsp;+&nbsp;m&nbsp;-&nbsp;1)&nbsp;%&nbsp;n&nbsp;+&nbsp;1</pre><p>其中，josephus(n, m)表示最后胜利者的位置，n是总人数，m是报数的周期。当n=1时，josephus(1, m) = 1。</p><h2>练习题</h2><p>1. 使用迭代方法编写一个程序，解决约瑟夫环问题，并测试不同的人数、开始报数的位置和报数周期。</p><p>2. 使用数学公式编写一个程序，解决约瑟夫环问题，并与迭代方法的结果进行比较。</p><p>3. 思考约瑟夫环问题在不同情况下的应用，例如循环链表、密码学等。</p></div>',1111111,1,12),(45,20,'Python 3 教程','<div class=\"article-body\"><div class=\"article-intro\"><h1>Python 3 教程</h1><div class=\"tutintro\"><img src=\"https://www.runoob.com/wp-content/uploads/2014/05/python3.png\" alt=\"python3\" width=\"150\" height=\"81\"/><p>Python 的 3.0 版本，常被称为 Python 3000，或简称 Py3k。相对于 Python 的早期版本，这是一个较大的升级。为了不带入过多的累赘，Python 3.0 在设计的时候没有考虑向下兼容。</p><p>Python 介绍及安装教程我们在<a href=\"/python/python-tutorial.html\" target=\"_blank\">Python 2.X 版本的教程</a>中已有介绍，这里就不再赘述。<a></a></p><p><a>你也可以点击 </a><a target=\"_top\" href=\"python-2x-3x.html\"> Python2.x与3&amp;ZeroWidthSpace;&amp;ZeroWidthSpace;.x版本区别 </a>来查看两者的不同。</p><p>本教程主要针对 Python 3.x 版本的学习，如果你使用的是 Python 2.x 版本请移步至 <a href=\"/python/python-tutorial.html\" target=\"_blank\">Python 2.X 版本的教程</a>。</p><p><strong>官方宣布，2020 年 1 月 1 日， 停止 Python 2 的更新。</strong></p></div><hr/><h2>查看 Python 版本</h2><p>我们可以在命令窗口(Windows 使用 win+R 调出 cmd 运行框)使用以下命令查看我们使用的 Python 版本：</p><pre class=\"prettyprint prettyprinted\" style=\"\">python&nbsp;-V或python&nbsp;--version</pre><p>以上命令执行结果如下：</p><pre class=\"prettyprint prettyprinted\" style=\"\">Python&nbsp;3.3.2</pre><p>你也可以进入Python的交互式编程模式，查看版本：</p><pre class=\"prettyprint prettyprinted\" style=\"\">Python&nbsp;3.3.2&nbsp;(v3.3.2:d047928ae3f6,&nbsp;May&nbsp;16&nbsp;2013,&nbsp;00:03:43)&nbsp;[MSC&nbsp;v.1600&nbsp;32&nbsp;bit&nbsp;(Intel)]&nbsp;on&nbsp;win32Type&nbsp;&quot;copyright&quot;,&nbsp;&quot;credits&quot;&nbsp;or&nbsp;&quot;license()&quot;&nbsp;for&nbsp;more&nbsp;information.&gt;&gt;&gt;</pre><hr/><h2>第一个Python3.x程序</h2><p>对于大多数程序语言，第一个入门编程代码便是 <strong>&quot;Hello World！&quot;</strong>，以下代码为使用 Python 输出 <strong>&quot;Hello World！&quot;</strong>：</p><div class=\"example\"><h2 class=\"example\">hello.py 文件代码：</h2><div class=\"example_code\"><div class=\"hljs python\"><span class=\"hljs-comment\">#!/usr/bin/python3</span><br/><br/>print(<span class=\"hljs-string\">&quot;Hello, World!&quot;</span>)</div></div><br/><a target=\"_blank\" href=\"/try/runcode.php?filename=HelloWorld&type=python3\" class=\"showbtn\">运行实例 »</a></div><p>Python 常用文件扩展名为 <span class=\"marked\">.py</span>。</p><p>你可以将以上代码保存在 <strong>hello.py</strong> 文件中并使用 python 命令执行该脚本文件。</p><pre class=\"prettyprint prettyprinted\" style=\"\">$&nbsp;python3&nbsp;hello.py</pre><p>以上命令输出结果为：</p><pre class=\"prettyprint prettyprinted\" style=\"\">Hello,&nbsp;World!</pre><!-- 其他扩展 --></div></div>',6,1,0),(46,20,'Python3 环境搭建','<div class=\"article-body\"><div class=\"article-intro\"><h1>Python3 <span class=\"color_h1\">环境搭建</span></h1><p>本章节我们将向大家介绍如何在本地搭建 Python3 开发环境。</p><p>Python3 可应用于多平台包括 Windows、Linux 和 Mac OS X。</p><ul class=\" list-paddingleft-2\"><li><p>Unix (Solaris, Linux, FreeBSD, AIX, HP/UX, SunOS, IRIX, 等等。)</p></li><li><p>Win 9x/NT/2000</p></li><li><p>Macintosh (Intel, PPC, 68K)</p></li><li><p>OS/2</p></li><li><p>DOS (多个DOS版本)</p></li><li><p>PalmOS</p></li><li><p>Nokia 移动手机</p></li><li><p>Windows CE</p></li><li><p>Acorn/RISC OS</p></li><li><p>BeOS</p></li><li><p>Amiga</p></li><li><p>VMS/OpenVMS</p></li><li><p>QNX</p></li><li><p>VxWorks</p></li><li><p>Psion</p></li><li><p>Python 同样可以移植到 Java 和 .NET 虚拟机上。</p></li></ul><br/><hr/><h2>Python3 下载</h2><p>Python3 最新源码，二进制文档，新闻资讯等可以在 Python 的官网查看到：</p><p>Python 官网：<a href=\"https://www.python.org/\" target=\"_blank\">https://www.python.org/</a></p><p>你可以在以下链接中下载 Python 的文档，你可以下载 HTML、PDF 和 PostScript 等格式的文档。</p><p>Python文档下载地址：<a href=\"https://www.python.org/doc/\" target=\"_blank\">https://www.python.org/doc/</a></p><br/><hr/><h2>Python 安装</h2><p>Python 已经被移植在许多平台上（经过改动使它能够工作在不同平台上）。</p><p>您需要下载适用于您使用平台的二进制代码，然后安装 Python。</p><p>如果您平台的二进制代码是不可用的，你需要使用C编译器手动编译源代码。</p><p>编译的源代码，功能上有更多的选择性， 为 Python 安装提供了更多的灵活性。</p><p>以下是各个平台安装包的下载地址：</p><p><img src=\"//www.runoob.com/wp-content/uploads/2018/07/F2135662-1078-4EE2-BEBB-353F8D8E521F.jpg\"/></p><p><strong>Source Code</strong> 可用于 Linux 上的安装。</p><p>以下为不同平台上安装 Python3 的方法。</p><h3>Unix &amp; Linux 平台安装 Python3:</h3><p>以下为在 Unix &amp; Linux 平台上安装 Python 的简单步骤：</p><ul class=\"list list-paddingleft-2\"><li><p>打开 WEB 浏览器访问 <a href=\"https://www.python.org/downloads/source/\" target=\"_blank\">https://www.python.org/downloads/source/</a></p></li><li><p>选择适用于 Unix/Linux 的源码压缩包。</p></li><li><p>下载及解压压缩包 &nbsp;<strong>Python-3.x.x.tgz</strong>，<strong>3.x.x</strong> 为你下载的对应版本号。</p></li><li><p>如果你需要自定义一些选项修改 <em>Modules/Setup</em></p></li></ul><p>以<strong> Python3.6.1</strong> 版本为例：</p><pre class=\"prettyprint\">#&nbsp;tar&nbsp;-zxvf&nbsp;Python-3.6.1.tgz\r\n#&nbsp;cd&nbsp;Python-3.6.1\r\n#&nbsp;./configure\r\n#&nbsp;make&nbsp;&amp;&amp;&nbsp;make&nbsp;install</pre><p>检查 Python3 是否正常可用：</p><pre class=\"prettyprint\">#&nbsp;python3&nbsp;-V\r\nPython&nbsp;3.6.1</pre><h3>Window 平台安装 Python:</h3><p>以下为在 Window 平台上安装 Python 的简单步骤。</p><p>打开 WEB 浏览器访问 <a href=\"https://www.python.org/downloads/windows/\" target=\"_blank\">https://www.python.org/downloads/windows/</a> ：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2018/07/1bf7d20f853bf2c4a8f03c03c864982f.png\"/></p><p>这些链接提供了不同类型的 Python 安装文件，适用于不同类型的 Windows 系统和使用情景：</p><ul class=\" list-paddingleft-2\"><li><p><strong>Download Windows installer (64-bit)</strong>：64 位 Windows 系统的安装程序。</p></li><li><p><strong>Download Windows installer (ARM64)</strong>：适用于 ARM64 架构的 Windows 设备的安装程序。</p></li><li><p><strong>Download Windows embeddable package (64-bit)</strong>：64 位 Windows 系统的嵌入式包，可用于嵌入到应用程序中。</p></li><li><p><strong>Download Windows embeddable package (32-bit)</strong>：32 位 Windows 系统的嵌入式包，同样可用于嵌入到应用程序中。</p></li><li><p><strong>Download Windows embeddable package (ARM64)</strong>：适用于 ARM64 架构的 Windows 设备的嵌入式包。</p></li><li><p><strong>Download Windows installer (32-bit)</strong>：32 位 Windows 系统的安装程序。</p></li></ul><p>记得勾选 <strong>Add Python 3.6 to PATH</strong>。</p><p><img src=\"//www.runoob.com/wp-content/uploads/2018/07/20180226150011548.png\"/></p><p>按 <span class=\"marked\">Win+R</span> 键，输入 cmd 调出命令提示符，输入 python:</p><p><img src=\"//www.runoob.com/wp-content/uploads/2018/07/20170707155742110.png\"/></p><p>也可以在开始菜单中搜索 <strong>IDLE</strong>：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2018/07/460F6DFB-3BBF-4683-BEA0-23BE8DF021B0.jpg\"/></p><h3>MAC 平台安装 Python:</h3><p>MAC 系统都自带有 Python2.7 环境，你可以在链接 <a href=\"https://www.python.org/downloads/mac-osx/\" target=\"_blank\">https://www.python.org/downloads/mac-osx/</a> 上下载最新版安装 Python 3.x。</p><p>你也可以参考源码安装的方式来安装。</p><br/><hr/><h2>环境变量配置</h2><p>程序和可执行文件可以在许多目录，而这些路径很可能不在操作系统提供可执行文件的搜索路径中。</p><p>path(路径)存储在环境变量中，这是由操作系统维护的一个命名的字符串。这些变量包含可用的命令行解释器和其他程序的信息。</p><p>Unix 或 Windows 中路径变量为 PATH（UNIX 区分大小写，Windows 不区分大小写）。</p><p>在 Mac OS 中，安装程序过程中改变了 Python 的安装路径。如果你需要在其他目录引用 Python，你必须在 path 中添加 Python 目录。</p><h3>在 Unix/Linux 设置环境变量</h3><ul class=\" list-paddingleft-2\"><li><p><strong>在 csh shell:</strong> 输入 <br/></p><pre class=\"prettyprint\">setenv&nbsp;PATH&nbsp;&quot;$PATH:/usr/local/bin/python&quot;</pre><p>, 按下 <strong>Enter</strong>。</p></li><li><p><strong>在 bash shell (Linux) 输入 :</strong><br/></p><pre class=\"prettyprint\">export&nbsp;PATH=&quot;$PATH:/usr/local/bin/python&quot;</pre><p>按下 <strong>Enter</strong> 。</p></li><li><p><strong>在 sh 或者 ksh shell 输入:</strong> <br/></p><pre class=\"prettyprint\">PATH=&quot;$PATH:/usr/local/bin/python&quot;</pre><p>按下 Enter。</p></li></ul><p><strong>注意: </strong>/usr/local/bin/python 是 Python 的安装目录。</p><h3>在 Windows 设置环境变量</h3><p>在环境变量中添加Python目录：</p><p><strong>在命令提示框中(cmd) :</strong> 输入 <br/></p><pre class=\"prettyprint\">path=%path%;C:\\Python</pre> 按下&quot;Enter&quot;。<p><br/></p><p><strong>注意: </strong>C:\\Python 是Python的安装目录。</p><p>也可以通过以下方式设置：</p><ul class=\" list-paddingleft-2\"><li><p>右键点击&quot;计算机&quot;，然后点击&quot;属性&quot;</p></li><li><p>然后点击&quot;高级系统设置&quot;</p></li><li><p>选择&quot;系统变量&quot;窗口下面的&quot;Path&quot;,双击即可！</p></li><li><p><br/></p></li><li><p>然后在&quot;Path&quot;行，添加python安装路径即可(我的D:\\Python32)，所以在后面，添加该路径即可。<strong>ps：记住，路径直接用分号&quot;；&quot;隔开！</strong></p></li><li><p>最后设置成功以后，在cmd命令行，输入命令&quot;python&quot;，就可以有相关显示。</p></li></ul><p><img src=\"//www.runoob.com/wp-content/uploads/2013/11/201209201707594792.png\"/></p><hr/><h2>Python 环境变量</h2><p>下面几个重要的环境变量，它应用于Python：</p><table class=\"reference\"><tbody><tr class=\"firstRow\"><th>变量名</th><th>描述</th></tr><tr><td>PYTHONPATH</td><td>PYTHONPATH是Python搜索路径，默认我们import的模块都会从PYTHONPATH里面寻找。</td></tr><tr><td>PYTHONSTARTUP</td><td>Python启动后，先寻找PYTHONSTARTUP环境变量，然后执行此变量指定的文件中的代码。</td></tr><tr><td>PYTHONCASEOK</td><td>加入PYTHONCASEOK的环境变量, 就会使python导入模块的时候不区分大小写.</td></tr><tr><td>PYTHONHOME</td><td>另一种模块搜索路径。它通常内嵌于的PYTHONSTARTUP或PYTHONPATH目录中，使得两个模块库更容易切换。</td></tr></tbody></table><br/><hr/><h2>运行 Python</h2><p>有三种方式可以运行 Python：</p><h3>1、交互式解释器：</h3><p>你可以通过命令行窗口进入 Python 并开始在交互式解释器中开始编写 Python 代码。</p><p>你可以在 Unix、DOS 或任何其他提供了命令行或者 shell 的系统进行 Python 编码工作。</p><pre class=\"prettyprint\">$&nbsp;python&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#&nbsp;Unix/Linux\r\n\r\n或者&nbsp;&nbsp;\r\n\r\nC:&gt;python&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#&nbsp;Windows/DOS</pre><p>以下为 Python 命令行参数：</p><table class=\"reference\"><tbody><tr class=\"firstRow\"><th>选项</th><th>描述</th></tr><tr><td>-d</td><td>在解析时显示调试信息</td></tr><tr><td>-O</td><td>生成优化代码 ( .pyo 文件 )</td></tr><tr><td>-S</td><td>启动时不引入查找Python路径的位置</td></tr><tr><td>-V</td><td>输出Python版本号</td></tr><tr><td>-X</td><td>从 1.6版本之后基于内建的异常（仅仅用于字符串）已过时。</td></tr><tr><td>-c cmd</td><td>执行 Python 脚本，并将运行结果作为 cmd 字符串。</td></tr><tr><td>file</td><td>在给定的python文件执行python脚本。</td></tr></tbody></table><h3>2、命令行脚本</h3><p>在你的应用程序中通过引入解释器可以在命令行中执行Python脚本，如下所示：</p><pre class=\"prettyprint\">$&nbsp;python&nbsp;&nbsp;script.py&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#&nbsp;Unix/Linux\r\n\r\n或者\r\n\r\nC:&gt;python&nbsp;script.py&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#&nbsp;Windows/DOS</pre><p><strong>注意：</strong>在执行脚本时，请检查脚本是否有可执行权限。</p><h3>3、集成开发环境（IDE：Integrated Development Environment）: PyCharm</h3><p>PyCharm 是由 JetBrains 打造的一款 Python IDE，支持 macOS、 Windows、 Linux 系统。</p><p>PyCharm 功能 : 调试、语法高亮、Project管理、代码跳转、智能提示、自动完成、单元测试、版本控制……</p><p>PyCharm 下载地址 : <a href=\"https://www.jetbrains.com/pycharm/download/\" target=\"_blank\">https://www.jetbrains.com/pycharm/download/</a></p><p>PyCharm 安装地址：<a href=\"//www.runoob.com/w3cnote/pycharm-windows-install.html\" target=\"_blank\">http://www.runoob.com/w3cnote/pycharm-windows-install.html</a></p><p>Professional（专业版，收费）：完整的功能，可试用 30 天。</p><p>Community（社区版，免费）：阉割版的专业版。</p><p><img src=\"//www.runoob.com/wp-content/uploads/2018/05/1525863037-6053-.png\"/></p><p>PyCharm 界面：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2013/11/execute-python-hello-world-program.png\"/></p><p>安装 PyCharm 中文插件，打开菜单栏 File，选择 Settings，然后选 Plugins，点 Marketplace，搜索 chinese，然后点击 install 安装：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2013/11/aHR0cDovL3d3dy54aW1vcWluZy5jbi9kYXRhL3VwbG9hZHMvMjAyMDA0MjIvNTY1ODA1NTIyNDhhYTIwNmQzZThiMTQzNDVlZjc2NjEuanBn.jpeg\"/></p><br/><hr/><h2>Anaconda 集成环境</h2><p>Anaconda 发行版包含了 Python。</p><p>Anaconda 是一个集成的数据科学和机器学习环境，其中包括了 Python 解释器以及大量常用的数据科学库和工具。</p><p>Anaconda 包及其依赖项和环境的管理工具为 conda 命令，文与传统的 Python pip 工具相比 Anaconda 的conda 可以更方便地在不同环境之间进行切换，环境管理较为简单。</p><p>Anaconda详细安装与介绍参考：<a href=\"https://www.runoob.com/python-qt/anaconda-tutorial.html\" target=\"_blank\">Anaconda 教程。</a></p><!-- 其他扩展 --></div></div>',5,1,0),(47,20,'Python AI 编程助手','<div class=\"article-body\"><div class=\"article-intro\"><h1>Python AI 编程助手</h1><p>这两年 AI 发展迅猛，作为开发人员，我们总是追求更快、更高效的工作方式，AI 的出现可以说改变了很多人的编程方式。</p><p>AI 对我们来说就是一个可靠的编程助手，给我们提供了实时的建议和解决方案，无论是快速修复错误、提升代码质量，或者查找关键文档和资源，AI 作为编程助手都能让你事半功倍。</p><p>今天为大家推荐一款适配了 Viusal Studio，VS Code(本文使用)，JetBrains 系列(本文使用)以及Vim等多种编译器环境的插件 Fitten Code，Fitten Code 是由非十大模型驱动的 AI 编程助手，它可以自动生成代码，提升开发效率，帮您调试 Bug，节省您的时间，另外还可以对话聊天，解决您编程碰到的问题。</p><p>Fitten Code 免费且支持 80 多种语言：Python、C++、Javascript、Typescript、Java等。</p><p>目前对于 Python 语言，Fitten Code 支持在多种文本编辑器或 IDE 上使用，接下来我们来详细看看 VS Code 与 PyCharm 两款 IDE 的安装与使用：</p><p><strong><a href=\"#post-25200--2\">一、VS Code 版</a></strong></p><ul class=\" list-paddingleft-2\"><li><p><a href=\"#post-25200-2-1\">1. 安装</a></p></li><li><p><a href=\"#post-25200-2-2\">2. 智能补全</a></p></li><li><p><a href=\"#post-25200-2-3\">3. AI问答</a></p></li><li><p><a href=\"#post-25200-2-4\">4. 生成代码</a></p></li><li><p><a href=\"#post-25200-2-5\">5. 代码翻译</a></p></li><li><p><a href=\"#post-25200-2-6\">6. 生成注释</a></p></li><li><p><a href=\"#post-25200-2-7\">7. 解释代码</a></p></li><li><p><a href=\"#post-25200-2-8\">8. 生成测试</a></p></li><li><p><a href=\"#post-25200-2-9\">9. 检查 BUG</a></p></li><li><p><a href=\"#post-25200-2-10\">10. 编辑代码</a></p></li><li><p><a href=\"#post-25200-2-11\">11. 常见问题</a></p></li></ul><p><strong><a href=\"#post-25200--1\">二、PyCharm 版</a></strong></p><ul class=\" list-paddingleft-2\"><li><p><a>1. 安装</a></p></li><li><p><a href=\"#post-25200-2\">2. 智能补全</a></p></li><li><p><a href=\"#post-25200-3\">3. AI问答</a></p></li><li><p><a href=\"#post-25200-4\">4. 生成代码</a></p></li><li><p><a href=\"#post-25200-5\">5. 代码翻译</a></p></li><li><p><a href=\"#post-25200-6\">6. 生成注释</a></p></li><li><p><a href=\"#post-25200-7\">7. 解释代码</a></p></li><li><p><a href=\"#post-25200-8\">8. 生成测试</a></p></li><li><p><a href=\"#post-25200-9\">9. 检查 BUG</a></p></li><li><p><a href=\"#post-25200-10\">10. 编辑代码</a></p></li></ul><h2>一、Visual Studio 版本</h2><h3>1、安装</h3><p>如果您已经安装 VS Code 且版本大于等于1.68.0，请直接跳过此步骤，否则请点击<a target=\"_blank\" href=\"https://code.visualstudio.com/download\">下载</a>前往官网下载安装 VS Code。</p><p>打开 VS Code，点击左侧 Extensions（扩展）按钮：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/img_256.png\"/></p><p>在搜索框中搜索关键字&nbsp;Fitten Code：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/img_256-1.png\"/></p><p>在搜索结果中点击Install：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/img_256-2.png\"/></p><p>登录注册后即可开始使用：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/img_256.jpeg\"/></p><h3>2、智能补全</h3><p>打开代码文件，输入一段代码，Fitten Code&nbsp;就会为您自动补全代码：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-23.png\"/></p><p>按下&nbsp;Tab&nbsp;键接受所有补全建议：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-24.png\"/></p><p>按下&nbsp;Ctrl+→&nbsp;键(mac系统为Command+→)接收单个词补全建议：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-25.png\"/></p><h3>3、AI 问答</h3><p>用户可通过点击左上角工具栏中的Fitten Code&nbsp;–&nbsp;开始对话或者使用快捷键Ctrl+Alt+C(mac系统为Control+Option+C)打开对话窗口进行对话：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-26.png\"/></p><p>当用户选中代码段再进行对话时，Fitten Code&nbsp;会自动引用用户所选中的代码段，此时可直接针对该代码段进行问询等操作：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-27.png\"/></p><h3>4、生成代码</h3><p>可在左侧&nbsp;Fitten Code&nbsp;工具栏中选择&nbsp;&quot;Fitten Code - 生成代码&quot;&nbsp;或者使用快捷键&nbsp;Ctrl+Alt+G (mac系统为Control+Option+G)，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-28.png\"/></p><p>然后在输入框中输入指令即可生成代码：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-29.png\"/></p><p>利用对话功能生成代码：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-30.png\"/></p><h3>5、代码翻译</h3><p>编辑代码功能可以实现不同语言之间的转换，如Python语法转换成C++语法等。选中需要进行编辑的代码段，右键选择&nbsp;&quot;Fitten Code – 编辑代码&quot;&nbsp;或点击左侧工具栏中的&nbsp;&quot;Fitten Code – 编辑代码&quot;&nbsp;或者使用快捷键&nbsp;Ctrl+Alt+E (mac系统为Control+Option+E)，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-31.png\"/></p><p>然后在输入框中输入需求(如此处要求Fitten将python代码转为C++代码)：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-32.png\"/></p><p>也可以在Chat界面实现：选中需要进行编辑的代码段，右键选择&nbsp;&quot;Fitten Code – 开始聊天&quot;&nbsp;或点击左侧工具栏中的&nbsp;&quot;Fitten Code – 开始聊天&quot;&nbsp;或者使用快捷键&nbsp;Ctrl+Alt+C, 如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-33.png\"/></p><h3>6、生成注释</h3><p>Fitten Code&nbsp;能够根据您的代码自动生成相关注释，通过分析您的代码逻辑和结构，为您的代码提供清晰易懂的解释和文档，不仅提高代码的可读性，还方便其他开发人员理解和使用您的代码。先选中需要生成注释的代码段，然后右键选择&nbsp;&quot;Fitten Code – 生成注释&quot;：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-34.png\"/></p><p>即可生成对应注释如下图所示，点击&quot;Apply&quot;后即可应用：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-35.png\"/></p><h3>7、解释代码</h3><p>Fitten Code&nbsp;可以对一段代码进行解释，可以通过选中代码段然后右键选择&nbsp;&quot;Fitten Code – 解释代码&quot;&nbsp;进行解释，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-36.png\"/></p><p>此外，还可以进一步回答用户关于这段代码的疑问，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-37.png\"/></p><h3>8、生成测试</h3><p>Fitten Code&nbsp;拥有自动生成单元测试的功能，可以根据代码自动产生相应的测试用例，提高代码质量和可靠性。通过选中代码段后右键选择&nbsp;&quot;Fitten Code – 生成单元测试&quot;&nbsp;来实现，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-38.png\"/></p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-39.png\"/></p><h3>9、检查 BUG</h3><p>Fitten Code 可以对一段代码检查可能的 bug，并给出修复建议。选中对应代码段，然后右键选择&nbsp;&quot;Fitten Code查找Bug&quot;，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-40.png\"/></p><h3>10、编辑代码</h3><p>Fitten Code可根据用户指示对选定的代码块进行编辑，用户点击&nbsp;&quot;Apply&quot;&nbsp;后即可应用变更。通过选中代码段右键选择&nbsp;&quot;Fitten Code – 编辑代码&quot;&nbsp;或在左上角工具栏点击&nbsp;&quot;Fitten Code – 编辑代码&quot;，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-41.png\"/></p><p>随后，用户可在输入框中输入指示，Fitten Code&nbsp;会新建一个窗口对比显示更改前和更改后的内容，用户可通过点击&nbsp;&quot;Apply&quot;&nbsp;应用更改，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-42.png\"/></p><h3>11、常见问题</h3><p>如果 VSCode 远程服务器 remote 无法连接外网时，请点击左下角⚙按钮，再点击设置：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/img_277.png\"/></p><p>然后在设置页面点击右上角&nbsp;&quot;打开设置(JSON)&quot;:</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/img_278.png\"/></p><p>最后只需在在弹出的&nbsp;settings.json&nbsp;文件中添加以下内容即可:</p><pre class=\"prettyprint prettyprinted\" style=\"\">&quot;remote.extensionKind&quot;:&nbsp;{&nbsp;&quot;FittenTech.Fitten-Code&quot;:&nbsp;[&quot;ui&quot;]&nbsp;}</pre><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/img_279.png\"/></p><p>更多内容参考官网：<a target=\"_blank\" href=\"https://code.fittentech.com/\">https://code.fittentech.com/</a></p><p>支持以下 4 种编辑器与开发环境：</p><ul class=\" list-paddingleft-2\"><li><p><a href=\"https://code.fittentech.com/tutor_vscode_zh\" target=\"_blank\">VS Code</a>：本文已详细介绍</p></li><li><p><a href=\"https://code.fittentech.com/tutor_jetbrains_zh\" target=\"_blank\">JetBrains IDE 系列（包括PyCharm）</a></p></li><li><p><a href=\"https://code.fittentech.com/tutor_vs_zh\" target=\"_blank\">Visual Studio</a></p></li><li><p><a href=\"https://code.fittentech.com/tutor_vim_zh\" target=\"_blank\">Vim</a></p></li></ul><hr/><h2>二、PyCharm 版本</h2><h3>1、安装</h3><p>点击左上方&quot;文件&quot;再点击&quot;设置&quot;，如下图所示</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-1.png\"/></p><p>接着点击左侧&quot;插件&quot;选择&quot;Marketplace&quot;，并搜索&quot;Fitten Code&quot;，然后点击&quot;安装&quot;进行安装</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-2.png\"/></p><p>安装完成后左侧会出现Fitten Code插件图标,注册登录后即可开始使用</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-3.png\"/></p><h3>2、智能补全</h3><p>打开代码文件，输入一段代码，Fitten Code&nbsp;就会为您自动补全代码：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-4.png\"/></p><p>按下&nbsp;Tab&nbsp;键接受所有补全建议：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-5.png\"/></p><p>按下&nbsp;Ctrl+→&nbsp;键接收单个词补全建议：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-6.png\"/></p><h3>3、AI 问答</h3><p>用户可通过点击左上角工具栏中的Fitten Code&nbsp;–&nbsp;开始新对话打开对话窗口进行对话：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-7.png\"/></p><p>当选中代码段再通过右键的开始聊天功能进行对话时，Fitten Code&nbsp;会自动引用所选中的代码段，此时可直接针对该代码段进行问询等操作：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-8.png\"/></p><h3>4、生成代码</h3><p>可在左侧&nbsp;Fitten Code&nbsp;工具栏中选择&nbsp;&quot;Fitten Code - 生成代码&quot;&nbsp; ，然后在输入框中输入指令即可生成代码：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-9.png\"/></p><p>利用注释后的自动补全功能生成代码</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-10.png\"/></p><p>也可以利用对话功能生成代码</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-11.png\"/></p><h3>5、代码翻译</h3><p>Fitten Code可以实现代码的语义级翻译，并支持多种编程语言之间的互译。有以下两种方法可以实现。</p><p>（1）选中需要进行翻译的代码段，右键选择&quot;Fitten Code – 编辑代码&quot;，然后在输入框中输入需求即可完成转换</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-12.png\"/></p><p>（2）选中需要进行翻译的代码段，点击左侧工具栏中的&quot;开始新对话&quot;。然后在输入框中输入需求即可完成转换</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-13.png\"/></p><h3>6、生成注释</h3><p>Fitten Code&nbsp;能够根据您的代码自动生成相关注释，通过分析您的代码逻辑和结构，为您的代码提供清晰易懂的解释和文档，不仅提高代码的可读性，还方便其他开发人员理解和使用您的代码。先选中需要生成注释的代码段，然后右键选择&nbsp;&quot;Fitten Code – 生成注释&quot;：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-14.png\"/></p><h3>7、解释代码</h3><p>Fitten Code&nbsp;可以对一段代码进行解释，可以通过选中代码段然后右键选择&nbsp;&quot;Fitten Code – 解释代码&quot;&nbsp;进行解释，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-15.png\"/></p><h3>8、生成测试</h3><p>Fitten Code&nbsp;拥有自动生成单元测试的功能，可以根据代码自动产生相应的测试用例，提高代码质量和可靠性。通过选中代码段后右键选择&nbsp;&quot;Fitten Code – 生成单元测试&quot;&nbsp;来实现，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-16.png\"/></p><h3>9、检查 BUG</h3><p>Fitten Code 可以对一段代码检查可能的 bug，并给出修复建议。选中对应代码段，然后右键选择&nbsp;&quot;Fitten Code查找Bug&quot;，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/unnamed-file.png\"/></p><h3>10、编辑代码</h3><p>Fitten Code可根据用户指示对选定的代码块进行编辑。通过选中代码段右键选择&nbsp;&quot;Fitten Code – 编辑代码&quot;&nbsp;，如下图所示：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2024/03/word-image-25200-18.png\"/></p><p>更多内容参考官网：<a target=\"_blank\" href=\"https://code.fittentech.com/\">https://code.fittentech.com/</a></p><p>支持以下 4 种编辑器与开发环境：</p><ul class=\" list-paddingleft-2\"><li><p><a href=\"https://code.fittentech.com/tutor_vscode_zh\" target=\"_blank\">VS Code</a> ：本文已详细介绍</p></li><li><p><a href=\"https://code.fittentech.com/tutor_jetbrains_zh\" target=\"_blank\">JetBrains IDE 系列（包括PyCharm）</a>：本文已详细介绍</p></li><li><p><a href=\"https://code.fittentech.com/tutor_vs_zh\" target=\"_blank\">Visual Studio</a></p></li><li><p><a href=\"https://code.fittentech.com/tutor_vim_zh\" target=\"_blank\">Vim</a></p></li></ul><!-- 其他扩展 --></div></div>',4,1,1),(48,20,'Python3 基础语法','<p>1</p>',3,1,0),(49,20,'Python3 基本数据类型','<div class=\"article-body\"><div class=\"article-intro\"><h1>Python3 基本数据类型</h1><p>Python 中的变量不需要声明。每个变量在使用前都必须赋值，变量赋值以后该变量才会被创建。</p><p>在 Python 中，变量就是变量，它没有类型，我们所说的&quot;类型&quot;是变量所指的内存中对象的类型。</p><p>等号（=）用来给变量赋值。</p><p>等号（=）运算符左边是一个变量名,等号（=）运算符右边是存储在变量中的值。例如：</p><div class=\"example\"><h2 class=\"example\">实例(Python 3.0+)</h2><div class=\"example_code\"><span style=\"color: #a50\">#!/usr/bin/python3</span><br/><br/>counter <span style=\"color: Gray;\">=</span> <span style=\"color: Maroon;\">100</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 整型变量</span><br/>miles &nbsp; <span style=\"color: Gray;\">=</span> <span style=\"color: Maroon;\">1000.0</span> &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 浮点型变量</span><br/>name &nbsp; &nbsp;<span style=\"color: Gray;\">=</span> <span style=\"color: #a11;\">&quot;runoob&quot;</span> &nbsp; &nbsp; <span style=\"color: #a50\"># 字符串</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>counter<span style=\"color: Olive;\">)</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>miles<span style=\"color: Olive;\">)</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>name<span style=\"color: Olive;\">)</span><br/></div><br/><a target=\"_blank\" href=\"/try/runcode.php?filename=basic_data_type1&type=python3\" class=\"showbtn\">运行实例 »</a></div><p>执行以上程序会输出如下结果：</p><pre class=\"prettyprint prettyprinted\" style=\"\">1001000.0runoob</pre><h3>多个变量赋值</h3><p>Python允许你同时为多个变量赋值。例如：</p><pre class=\"prettyprint prettyprinted\" style=\"\">a&nbsp;=&nbsp;b&nbsp;=&nbsp;c&nbsp;=&nbsp;1</pre><p>以上实例，创建一个整型对象，值为 1，从后向前赋值，三个变量被赋予相同的数值。</p><p>您也可以为多个对象指定多个变量。例如：</p><pre class=\"prettyprint prettyprinted\" style=\"\">a,&nbsp;b,&nbsp;c&nbsp;=&nbsp;1,&nbsp;2,&nbsp;&quot;runoob&quot;</pre><p>以上实例，两个整型对象 1 和 2 的分配给变量 a 和 b，字符串对象 &quot;runoob&quot; 分配给变量 c。</p><hr/><h2>标准数据类型</h2><p>Python3 中常见的数据类型有：</p><ul class=\" list-paddingleft-2\"><li><p>Number（数字）</p></li><li><p>String（字符串）</p></li><li><p>bool（布尔类型）</p></li><li><p>List（列表）</p></li><li><p>Tuple（元组）</p></li><li><p>Set（集合）</p></li><li><p>Dictionary（字典）</p></li></ul><p>Python3 的六个标准数据类型中：</p><ul class=\" list-paddingleft-2\"><li><p><strong>不可变数据（3 个）：</strong>Number（数字）、String（字符串）、Tuple（元组）；</p></li><li><p><strong>可变数据（3 个）：</strong>List（列表）、Dictionary（字典）、Set（集合）。</p></li></ul><p>此外还有一些高级的数据类型，如: 字节数组类型(bytes)。</p><hr/><h2>Number（数字）</h2><p>Python3 支持 <strong>int、float、bool、complex（复数）</strong>。</p><p>在Python 3里，只有一种整数类型 int，表示为长整型，没有 python2 中的 Long。</p><p>像大多数语言一样，数值类型的赋值和计算都是很直观的。</p><p>内置的 type() 函数可以用来查询变量所指的对象类型。</p><pre class=\"prettyprint prettyprinted\" style=\"\">&gt;&gt;&gt;&nbsp;a,&nbsp;b,&nbsp;c,&nbsp;d&nbsp;=&nbsp;20,&nbsp;5.5,&nbsp;True,&nbsp;4+3j&gt;&gt;&gt;&nbsp;print(type(a),&nbsp;type(b),&nbsp;type(c),&nbsp;type(d))&lt;class&nbsp;&#39;int&#39;&gt;&nbsp;&lt;class&nbsp;&#39;float&#39;&gt;&nbsp;&lt;class&nbsp;&#39;bool&#39;&gt;&nbsp;&lt;class&nbsp;&#39;complex&#39;&gt;</pre><p>此外还可以用 isinstance 来判断：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Gray;\">&gt;&gt;&gt;</span> a <span style=\"color: Gray;\">=</span> <span style=\"color: Maroon;\">111</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Teal;\">isinstance</span><span style=\"color: Olive;\">(</span>a<span style=\"color: Gray;\">,</span> <span style=\"color: Teal;\">int</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Teal;\">True</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <br/></div></div><p>isinstance 和 type 的区别在于：</p><ul class=\" list-paddingleft-2\"><li><p>type()不会认为子类是一种父类类型。</p></li><li><p>isinstance()会认为子类是一种父类类型。</p></li></ul><pre class=\"prettyprint prettyprinted\" style=\"\">&gt;&gt;&gt;&nbsp;class&nbsp;A:...&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pass...&nbsp;&gt;&gt;&gt;&nbsp;class&nbsp;B(A):...&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;pass...&nbsp;&gt;&gt;&gt;&nbsp;isinstance(A(),&nbsp;A)True&gt;&gt;&gt;&nbsp;type(A())&nbsp;==&nbsp;A&nbsp;\r\nTrue&gt;&gt;&gt;&nbsp;isinstance(B(),&nbsp;A)True&gt;&gt;&gt;&nbsp;type(B())&nbsp;==&nbsp;AFalse</pre><blockquote><p><strong>注意：</strong>Python3 中，bool 是 int 的子类，True 和 False 可以和数字相加， <span class=\"marked\">True==1、False==0</span> 会返回 <strong>True</strong>，但可以通过 <span class=\"marked\">is</span> 来判断类型。</p><pre class=\"prettyprint prettyprinted\" style=\"\">&gt;&gt;&gt;&nbsp;issubclass(bool,&nbsp;int)&nbsp;True&gt;&gt;&gt;&nbsp;True==1True&gt;&gt;&gt;&nbsp;False==0True&gt;&gt;&gt;&nbsp;True+12&gt;&gt;&gt;&nbsp;False+11&gt;&gt;&gt;&nbsp;1&nbsp;is&nbsp;TrueFalse&gt;&gt;&gt;&nbsp;0&nbsp;is&nbsp;FalseFalse</pre><p>在 Python2 中是没有布尔型的，它用数字 0 表示 False，用 1 表示 True。</p></blockquote><p>当你指定一个值时，Number 对象就会被创建：</p><pre class=\"prettyprint prettyprinted\" style=\"\">var1&nbsp;=&nbsp;1var2&nbsp;=&nbsp;10</pre><p>您也可以使用del语句删除一些对象引用。</p><p>del语句的语法是：</p><pre class=\"prettyprint prettyprinted\" style=\"\">del&nbsp;var1[,var2[,var3[....,varN]]]</pre><p>您可以通过使用del语句删除单个或多个对象。例如：</p><pre class=\"prettyprint prettyprinted\" style=\"\">del&nbsp;vardel&nbsp;var_a,&nbsp;var_b</pre><h3>数值运算</h3><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Maroon;\">5</span> + <span style=\"color: Maroon;\">4</span> &nbsp;<span style=\"color: #a50\"># 加法</span><br/><span style=\"color: Maroon;\">9</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Maroon;\">4.3</span> - <span style=\"color: Maroon;\">2</span> <span style=\"color: #a50\"># 减法</span><br/><span style=\"color: Maroon;\">2.3</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Maroon;\">3</span> * <span style=\"color: Maroon;\">7</span> &nbsp;<span style=\"color: #a50\"># 乘法</span><br/><span style=\"color: Maroon;\">21</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Maroon;\">2</span> / <span style=\"color: Maroon;\">4</span> &nbsp;<span style=\"color: #a50\"># 除法，得到一个浮点数</span><br/><span style=\"color: Maroon;\">0.5</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Maroon;\">2</span> // <span style=\"color: Maroon;\">4</span> <span style=\"color: #a50\"># 除法，得到一个整数</span><br/><span style=\"color: Maroon;\">0</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Maroon;\">17</span> % <span style=\"color: Maroon;\">3</span> <span style=\"color: #a50\"># 取余 </span><br/><span style=\"color: Maroon;\">2</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Maroon;\">2</span> ** <span style=\"color: Maroon;\">5</span> <span style=\"color: #a50\"># 乘方</span><br/><span style=\"color: Maroon;\">32</span><br/></div></div><p><strong>注意：</strong></p><ul class=\" list-paddingleft-2\"><li><p>1、Python可以同时为多个变量赋值，如a, b = 1, 2。</p></li><li><p>2、一个变量可以通过赋值指向不同类型的对象。</p></li><li><p>3、数值的除法包含两个运算符：<span class=\"marked\">/</span> 返回一个浮点数，<span class=\"marked\">//</span> 返回一个整数。</p></li><li><p>4、在混合计算时，Python会把整型转换成为浮点数。</p></li></ul><h3>数值类型实例</h3><table class=\"reference\"><tbody><tr class=\"firstRow\"><th>int</th><th>float</th><th>complex</th></tr><tr><td>10</td><td>0.0</td><td>3.14j</td></tr><tr><td>100</td><td>15.20</td><td>45.j</td></tr><tr><td>-786</td><td>-21.9</td><td>9.322e-36j</td></tr><tr><td>080</td><td>32.3e+18</td><td>.876j</td></tr><tr><td>-0490</td><td>-90.</td><td>-.6545+0J</td></tr><tr><td>-0x260</td><td>-32.54e100</td><td>3e+26J</td></tr><tr><td>0x69</td><td>70.2E-12</td><td>4.53e-7j</td></tr></tbody></table><p>Python 还支持复数，复数由实数部分和虚数部分构成，可以用 <span class=\"marked\">a + bj</span>，或者 <span class=\"marked\">complex(a,b)</span> 表示， 复数的实部 <strong>a</strong> 和虚部 <strong>b</strong> 都是浮点型。</p><hr/><h2>String（字符串）</h2><p>Python中的字符串用单引号 <span class=\"marked\">&#39;</span> 或双引号 <span class=\"marked\">&quot;</span> 括起来，同时使用反斜杠 <span class=\"marked\">\\</span> 转义特殊字符。</p><p>字符串的截取的语法格式如下：</p><pre class=\"prettyprint prettyprinted\" style=\"\">变量[头下标:尾下标]</pre><p>索引值以 0 为开始值，-1 为从末尾的开始位置。</p><p><img src=\"https://static.jyshare.com/wp-content/uploads/123456-20200923-1.svg\"/></p><p>加号 &nbsp;<span class=\"marked\">+</span> &nbsp;是字符串的连接符， 星号 &nbsp;<span class=\"marked\">*</span> &nbsp;表示复制当前字符串，与之结合的数字为复制的次数。实例如下：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: #a50\">#!/usr/bin/python3</span><br/><br/><span style=\"color: Teal;\">str</span> <span style=\"color: Gray;\">=</span> <span style=\"color: #a11;\">&#39;Runoob&#39;</span> &nbsp;<span style=\"color: #a50\"># 定义一个字符串变量</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 打印整个字符串</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span>:-<span style=\"color: Maroon;\">1</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; <span style=\"color: #a50\"># 打印字符串第一个到倒数第二个字符（不包含倒数第一个字符）</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 打印字符串的第一个字符</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span>:<span style=\"color: Maroon;\">5</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 打印字符串第三到第五个字符（包含第五个字符）</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span>:<span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 打印字符串从第三个字符开始到末尾</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span> * <span style=\"color: Maroon;\">2</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 打印字符串两次</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span> + <span style=\"color: #a11;\">&quot;TEST&quot;</span><span style=\"color: Olive;\">)</span> &nbsp;<span style=\"color: #a50\"># 打印字符串和&quot;TEST&quot;拼接在一起</span><br/></div></div><p>执行以上程序会输出如下结果：</p><pre class=\"prettyprint prettyprinted\" style=\"\">RunoobRunooR\r\nnoo\r\nnoobRunoobRunoobRunoobTEST</pre><p>Python 使用反斜杠 <span class=\"marked\">\\</span> 转义特殊字符，如果你不想让反斜杠发生转义，可以在字符串前面添加一个 <span class=\"marked\">r</span>，表示原始字符串：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;Ru<span style=\"color: #000099; font-weight: bold;\">\\n</span>oob&#39;</span><span style=\"color: Olive;\">)</span><br/>Ru<br/>oob<br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>r<span style=\"color: #a11;\">&#39;Ru<span style=\"color: #000099; font-weight: bold;\">\\n</span>oob&#39;</span><span style=\"color: Olive;\">)</span><br/>Ru\\noob<br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <br/></div></div><p>另外，反斜杠(\\)可以作为续行符，表示下一行是上一行的延续。也可以使用 <strong>&quot;&quot;&quot;...&quot;&quot;&quot;</strong> 或者 <strong>&#39;&#39;&#39;...&#39;&#39;&#39;</strong> 跨越多行。</p><p>注意，Python 没有单独的字符类型，一个字符就是长度为1的字符串。</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Gray;\">&gt;&gt;&gt;</span> word <span style=\"color: Gray;\">=</span> <span style=\"color: #a11;\">&#39;Python&#39;</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>word<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span><span style=\"color: Gray;\">,</span> word<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">5</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span><br/>P n<br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>word<span style=\"color: Olive;\">[</span>-<span style=\"color: Maroon;\">1</span><span style=\"color: Olive;\">]</span><span style=\"color: Gray;\">,</span> word<span style=\"color: Olive;\">[</span>-<span style=\"color: Maroon;\">6</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span><br/>n P<br/></div></div><p>与 C 字符串不同的是，Python 字符串不能被改变。向一个索引位置赋值，比如 <span class=\"marked\">word[0] = &#39;m&#39;</span> 会导致错误。</p><p><strong>注意：</strong></p><ul class=\" list-paddingleft-2\"><li><p>1、反斜杠可以用来转义，使用r可以让反斜杠不发生转义。</p></li><li><p>2、字符串可以用+运算符连接在一起，用*运算符重复。</p></li><li><p>3、Python中的字符串有两种索引方式，从左往右以0开始，从右往左以-1开始。</p></li><li><p>4、Python中的字符串不能改变。</p></li></ul><hr/><h2>bool（布尔类型）</h2><p>布尔类型即 True 或 False。</p><p>在 Python 中，True 和 False 都是关键字，表示布尔值。</p><p>布尔类型可以用来控制程序的流程，比如判断某个条件是否成立，或者在某个条件满足时执行某段代码。</p><p>布尔类型特点：</p><ul class=\" list-paddingleft-2\"><li><p>布尔类型只有两个值：True 和 False。</p></li><li><p>布尔类型可以和其他数据类型进行比较，比如数字、字符串等。在比较时，Python 会将 True 视为 1，False 视为 0。</p></li><li><p>布尔类型可以和逻辑运算符一起使用，包括 and、or 和 not。这些运算符可以用来组合多个布尔表达式，生成一个新的布尔值。</p></li><li><p>布尔类型也可以被转换成其他数据类型，比如整数、浮点数和字符串。在转换时，True 会被转换成 1，False 会被转换成 0。</p></li></ul><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\">a <span style=\"color: Gray;\">=</span> <span style=\"color: Teal;\">True</span><br/>b <span style=\"color: Gray;\">=</span> <span style=\"color: Teal;\">False</span><br/><br/><span style=\"color: #a50\"># 比较运算符</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Maroon;\">2</span> <span style=\"color: Gray;\">&lt;</span> <span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">)</span> &nbsp; <span style=\"color: #a50\"># True</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Maroon;\">2</span> <span style=\"color: Gray;\">==</span> <span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">)</span> &nbsp;<span style=\"color: #a50\"># False</span><br/><br/><span style=\"color: #a50\"># 逻辑运算符</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>a <span style=\"color: Green;font-weight:bold;\">and</span> b<span style=\"color: Olive;\">)</span> &nbsp;<span style=\"color: #a50\"># False</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>a <span style=\"color: Green;font-weight:bold;\">or</span> b<span style=\"color: Olive;\">)</span> &nbsp; <span style=\"color: #a50\"># True</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Green;font-weight:bold;\">not</span> a<span style=\"color: Olive;\">)</span> &nbsp; &nbsp;<span style=\"color: #a50\"># False</span><br/><br/><span style=\"color: #a50\"># 类型转换</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">int</span><span style=\"color: Olive;\">(</span>a<span style=\"color: Olive;\">)</span><span style=\"color: Olive;\">)</span> &nbsp; <span style=\"color: #a50\"># 1</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">float</span><span style=\"color: Olive;\">(</span>b<span style=\"color: Olive;\">)</span><span style=\"color: Olive;\">)</span> <span style=\"color: #a50\"># 0.0</span><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">str</span><span style=\"color: Olive;\">(</span>a<span style=\"color: Olive;\">)</span><span style=\"color: Olive;\">)</span> &nbsp; <span style=\"color: #a50\"># &quot;True&quot;</span><br/></div></div><p><strong>注意:</strong> 在 Python 中，所有非零的数字和非空的字符串、列表、元组等数据类型都被视为 True，只有 <strong>0、空字符串、空列表、空元组</strong>等被视为 False。因此，在进行布尔类型转换时，需要注意数据类型的真假性。</p><hr/><h2>List（列表）</h2><p>List（列表） 是 Python 中使用最频繁的数据类型。</p><p>列表可以完成大多数集合类的数据结构实现。列表中元素的类型可以不相同，它支持数字，字符串甚至可以包含列表（所谓嵌套）。</p><p>列表是写在方括号 <span class=\"marked\">[]</span> 之间、用逗号分隔开的元素列表。</p><p>和字符串一样，列表同样可以被索引和截取，列表被截取后返回一个包含所需元素的新列表。</p><p>列表截取的语法格式如下：</p><pre class=\"prettyprint prettyprinted\" style=\"\">变量[头下标:尾下标]</pre><p>索引值以 <span class=\"marked\">0</span> 为开始值，<span class=\"marked\">-1</span> 为从末尾的开始位置。</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2014/08/list_slicing1_new1.png\"/></p><p>加号 <span class=\"marked\">+</span> 是列表连接运算符，星号 <span class=\"marked\">*</span> 是重复操作。如下实例：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: #a50\">#!/usr/bin/python3</span><br/><br/><span style=\"color: Teal;\">list</span> <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">[</span> <span style=\"color: #a11;\">&#39;abcd&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">786</span> <span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">2.23</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;runoob&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">70.2</span> <span style=\"color: Olive;\">]</span> &nbsp;<span style=\"color: #a50\"># 定义一个列表</span><br/>tinylist <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">123</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;runoob&#39;</span><span style=\"color: Olive;\">]</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">list</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 打印整个列表</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">list</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 打印列表的第一个元素</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">list</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">1</span>:<span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 打印列表第二到第四个元素（不包含第四个元素）</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">list</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span>:<span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 打印列表从第三个元素开始到末尾</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>tinylist * <span style=\"color: Maroon;\">2</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp;<span style=\"color: #a50\"># 打印tinylist列表两次</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">list</span> + tinylist<span style=\"color: Olive;\">)</span> &nbsp;<span style=\"color: #a50\"># 打印两个列表拼接在一起的结果</span><br/></div></div><p>以上实例输出结果：</p><pre class=\"prettyprint prettyprinted\" style=\"\">[&#39;abcd&#39;,&nbsp;786,&nbsp;2.23,&nbsp;&#39;runoob&#39;,&nbsp;70.2]abcd[786,&nbsp;2.23][2.23,&nbsp;&#39;runoob&#39;,&nbsp;70.2][123,&nbsp;&#39;runoob&#39;,&nbsp;123,&nbsp;&#39;runoob&#39;][&#39;abcd&#39;,&nbsp;786,&nbsp;2.23,&nbsp;&#39;runoob&#39;,&nbsp;70.2,&nbsp;123,&nbsp;&#39;runoob&#39;]</pre><p>与Python字符串不一样的是，列表中的元素是可以改变的：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Gray;\">&gt;&gt;&gt;</span> a <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">1</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">3</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">4</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">5</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">6</span><span style=\"color: Olive;\">]</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> a<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span> <span style=\"color: Gray;\">=</span> <span style=\"color: Maroon;\">9</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> a<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span>:<span style=\"color: Maroon;\">5</span><span style=\"color: Olive;\">]</span> <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">13</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">14</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">15</span><span style=\"color: Olive;\">]</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> a<br/><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">9</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">13</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">14</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">15</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">6</span><span style=\"color: Olive;\">]</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> a<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span>:<span style=\"color: Maroon;\">5</span><span style=\"color: Olive;\">]</span> <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">[</span><span style=\"color: Olive;\">]</span> &nbsp; <span style=\"color: #a50\"># 将对应的元素值设置为 [] </span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> a<br/><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">9</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">6</span><span style=\"color: Olive;\">]</span><br/></div></div><p>List 内置了有很多方法，例如 append()、pop() 等等，这在后面会讲到。</p><p><strong>注意：</strong></p><ul class=\" list-paddingleft-2\"><li><p>1、列表写在方括号之间，元素用逗号隔开。</p></li><li><p>2、和字符串一样，列表可以被索引和切片。</p></li><li><p>3、列表可以使用 <span class=\"marked\">+</span> 操作符进行拼接。</p></li><li><p>4、列表中的元素是可以改变的。</p></li></ul><p>Python 列表截取可以接收第三个参数，参数作用是截取的步长，以下实例在索引 1 到索引 4 的位置并设置为步长为 2（间隔一个位置）来截取字符串：</p><p><img src=\"https://www.runoob.com/wp-content/uploads/2014/08/py-dict-1.png\"/></p><p>如果第三个参数为负数表示逆向读取，以下实例用于翻转字符串：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Green;font-weight:bold;\">def</span> reverseWords<span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">input</span><span style=\"color: Olive;\">)</span>: <br/>&nbsp; &nbsp; &nbsp; <br/>&nbsp; &nbsp; <span style=\"color: #a50\"># 通过空格将字符串分隔符，把各个单词分隔为列表</span><br/>&nbsp; &nbsp; inputWords <span style=\"color: Gray;\">=</span> <span style=\"color: Teal;\">input</span>.<span style=\"color: #05a;\">split</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&quot; &quot;</span><span style=\"color: Olive;\">)</span> <br/>&nbsp; <br/>&nbsp; &nbsp; <span style=\"color: #a50\"># 翻转字符串</span><br/>&nbsp; &nbsp; <span style=\"color: #a50\"># 假设列表 list = [1,2,3,4], &nbsp;</span><br/>&nbsp; &nbsp; <span style=\"color: #a50\"># list[0]=1, list[1]=2 ，而 -1 表示最后一个元素 list[-1]=4 ( 与 list[3]=4 一样) </span><br/>&nbsp; &nbsp; <span style=\"color: #a50\"># inputWords[-1::-1] 有三个参数</span><br/>&nbsp; &nbsp; <span style=\"color: #a50\"># 第一个参数 -1 表示最后一个元素</span><br/>&nbsp; &nbsp; <span style=\"color: #a50\"># 第二个参数为空，表示移动到列表末尾</span><br/>&nbsp; &nbsp; <span style=\"color: #a50\"># 第三个参数为步长，-1 表示逆向</span><br/>&nbsp; &nbsp; inputWords<span style=\"color: Gray;\">=</span>inputWords<span style=\"color: Olive;\">[</span>-<span style=\"color: Maroon;\">1</span>::-<span style=\"color: Maroon;\">1</span><span style=\"color: Olive;\">]</span> <br/>&nbsp; <br/>&nbsp; &nbsp; <span style=\"color: #a50\"># 重新组合字符串</span><br/>&nbsp; &nbsp; output <span style=\"color: Gray;\">=</span> <span style=\"color: #a11;\">&#39; &#39;</span>.<span style=\"color: #05a;\">join</span><span style=\"color: Olive;\">(</span>inputWords<span style=\"color: Olive;\">)</span> <br/>&nbsp; &nbsp; &nbsp; <br/>&nbsp; &nbsp; <span style=\"color: Green;font-weight:bold;\">return</span> output <br/>&nbsp; <br/><span style=\"color: Green;font-weight:bold;\">if</span> __name__ <span style=\"color: Gray;\">==</span> <span style=\"color: #a11;\">&quot;__main__&quot;</span>: <br/>&nbsp; &nbsp; <span style=\"color: Teal;\">input</span> <span style=\"color: Gray;\">=</span> <span style=\"color: #a11;\">&#39;I like runoob&#39;</span><br/>&nbsp; &nbsp; rw <span style=\"color: Gray;\">=</span> reverseWords<span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">input</span><span style=\"color: Olive;\">)</span> <br/>&nbsp; &nbsp; <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>rw<span style=\"color: Olive;\">)</span><br/></div></div><p>输出结果为：</p><pre class=\"prettyprint prettyprinted\" style=\"\">runoob&nbsp;like&nbsp;I</pre><hr/><h2>Tuple（元组）</h2><p>元组（tuple）与列表类似，不同之处在于元组的元素不能修改。元组写在小括号 <span class=\"marked\">()</span> 里，元素之间用逗号隔开。</p><p>元组中的元素类型也可以不相同：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: #a50\">#!/usr/bin/python3</span><br/><br/><span style=\"color: Teal;\">tuple</span> <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">(</span> <span style=\"color: #a11;\">&#39;abcd&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">786</span> <span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">2.23</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;runoob&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">70.2</span> &nbsp;<span style=\"color: Olive;\">)</span><br/>tinytuple <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">(</span><span style=\"color: Maroon;\">123</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;runoob&#39;</span><span style=\"color: Olive;\">)</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">tuple</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 输出完整元组</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">tuple</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 输出元组的第一个元素</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">tuple</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">1</span>:<span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 输出从第二个元素开始到第三个元素</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">tuple</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span>:<span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 输出从第三个元素开始的所有元素</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>tinytuple * <span style=\"color: Maroon;\">2</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; <span style=\"color: #a50\"># 输出两次元组</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">tuple</span> + tinytuple<span style=\"color: Olive;\">)</span> <span style=\"color: #a50\"># 连接元组</span><br/></div></div><p>以上实例输出结果：</p><pre class=\"prettyprint prettyprinted\" style=\"\">(&#39;abcd&#39;,&nbsp;786,&nbsp;2.23,&nbsp;&#39;runoob&#39;,&nbsp;70.2)abcd(786,&nbsp;2.23)(2.23,&nbsp;&#39;runoob&#39;,&nbsp;70.2)(123,&nbsp;&#39;runoob&#39;,&nbsp;123,&nbsp;&#39;runoob&#39;)(&#39;abcd&#39;,&nbsp;786,&nbsp;2.23,&nbsp;&#39;runoob&#39;,&nbsp;70.2,&nbsp;123,&nbsp;&#39;runoob&#39;)</pre><p>元组与字符串类似，可以被索引且下标索引从0开始，-1 为从末尾开始的位置。也可以进行截取（看上面，这里不再赘述）。</p><p>其实，可以把字符串看作一种特殊的元组。</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Gray;\">&gt;&gt;&gt;</span> tup <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">(</span><span style=\"color: Maroon;\">1</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">3</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">4</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">5</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">6</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>tup<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Maroon;\">1</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>tup<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">1</span>:<span style=\"color: Maroon;\">5</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Olive;\">(</span><span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">3</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">4</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">5</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> tup<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span> <span style=\"color: Gray;\">=</span> <span style=\"color: Maroon;\">11</span> &nbsp;<span style=\"color: #a50\"># 修改元组元素的操作是非法的</span><br/>Traceback <span style=\"color: Olive;\">(</span>most recent call last<span style=\"color: Olive;\">)</span>:<br/>&nbsp; File <span style=\"color: #a11;\">&quot;&lt;stdin&gt;&quot;</span><span style=\"color: Gray;\">,</span> line <span style=\"color: Maroon;\">1</span><span style=\"color: Gray;\">,</span> <span style=\"color: Green;font-weight:bold;\">in</span> <span style=\"color: Gray;\">&lt;</span>module<span style=\"color: Gray;\">&gt;</span><br/><span style=\"color: Teal;\">TypeError</span>: <span style=\"color: #a11;\">&#39;tuple&#39;</span> <span style=\"color: Teal;\">object</span> does <span style=\"color: Green;font-weight:bold;\">not</span> support item assignment<br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <br/></div></div><p>虽然tuple的元素不可改变，但它可以包含可变的对象，比如list列表。</p><p>构造包含 0 个或 1 个元素的元组比较特殊，所以有一些额外的语法规则：</p><pre class=\"prettyprint prettyprinted\" style=\"\">tup1&nbsp;=&nbsp;()&nbsp;&nbsp;&nbsp;&nbsp;#&nbsp;空元组tup2&nbsp;=&nbsp;(20,)&nbsp;#&nbsp;一个元素，需要在元素后添加逗号</pre><p>如果你想创建只有一个元素的元组，需要注意在元素后面添加一个逗号，以区分它是一个元组而不是一个普通的值，这是因为在没有逗号的情况下，Python会将括号解释为数学运算中的括号，而不是元组的表示。</p><p>如果不添加逗号，如下所示，它将被解释为一个普通的值而不是元组：</p><pre class=\"prettyprint prettyprinted\" style=\"\">not_a_tuple&nbsp;=&nbsp;(42)</pre><p>这样的话，not_a_tuple 将是整数类型而不是元组类型。</p><p>string、list 和 tuple 都属于 sequence（序列）。</p><p><strong>注意：</strong></p><ul class=\" list-paddingleft-2\"><li><p>1、与字符串一样，元组的元素不能修改。</p></li><li><p>2、元组也可以被索引和切片，方法一样。</p></li><li><p>3、注意构造包含 0 或 1 个元素的元组的特殊语法规则。</p></li><li><p>4、元组也可以使用 <span class=\"marked\">+</span> 操作符进行拼接。</p></li></ul><hr/><h2>Set（集合）</h2><p>Python 中的集合（Set）是一种无序、可变的数据类型，用于存储唯一的元素。</p><p>集合中的元素不会重复，并且可以进行交集、并集、差集等常见的集合操作。</p><p>在 Python 中，集合使用大括号 <span class=\"marked\">{}</span> 表示，元素之间用逗号 <span class=\"marked\">,</span> 分隔。</p><p>另外，也可以使用 <span class=\"marked\">set()</span> 函数创建集合。</p><p><strong>注意：</strong>创建一个空集合必须用<span class=\"marked\"> set()</span> 而不是 <span class=\"marked\">{ }</span>，因为 <span class=\"marked\">{ }</span> 是用来创建一个空字典。</p><p>创建格式：</p><pre class=\"prettyprint prettyprinted\" style=\"\">parame&nbsp;=&nbsp;{value01,value02,...}或者set(value)</pre><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: #a50\">#!/usr/bin/python3</span><br/><br/>sites <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">{</span><span style=\"color: #a11;\">&#39;Google&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Taobao&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Runoob&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Facebook&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Zhihu&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Baidu&#39;</span><span style=\"color: Olive;\">}</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>sites<span style=\"color: Olive;\">)</span> &nbsp; <span style=\"color: #a50\"># 输出集合，重复的元素被自动去掉</span><br/><br/><span style=\"color: #a50\"># 成员测试</span><br/><span style=\"color: Green;font-weight:bold;\">if</span> <span style=\"color: #a11;\">&#39;Runoob&#39;</span> <span style=\"color: Green;font-weight:bold;\">in</span> sites :<br/>&nbsp; &nbsp; <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;Runoob 在集合中&#39;</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Green;font-weight:bold;\">else</span> :<br/>&nbsp; &nbsp; <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;Runoob 不在集合中&#39;</span><span style=\"color: Olive;\">)</span><br/><br/><br/><span style=\"color: #a50\"># set可以进行集合运算</span><br/>a <span style=\"color: Gray;\">=</span> <span style=\"color: Teal;\">set</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;abracadabra&#39;</span><span style=\"color: Olive;\">)</span><br/>b <span style=\"color: Gray;\">=</span> <span style=\"color: Teal;\">set</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;alacazam&#39;</span><span style=\"color: Olive;\">)</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>a<span style=\"color: Olive;\">)</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>a - b<span style=\"color: Olive;\">)</span> &nbsp; &nbsp; <span style=\"color: #a50\"># a 和 b 的差集</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>a | b<span style=\"color: Olive;\">)</span> &nbsp; &nbsp; <span style=\"color: #a50\"># a 和 b 的并集</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>a &amp; b<span style=\"color: Olive;\">)</span> &nbsp; &nbsp; <span style=\"color: #a50\"># a 和 b 的交集</span><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span>a ^ b<span style=\"color: Olive;\">)</span> &nbsp; &nbsp; <span style=\"color: #a50\"># a 和 b 中不同时存在的元素</span><br/></div></div><p>以上实例输出结果：</p><pre class=\"prettyprint prettyprinted\" style=\"\">{&#39;Zhihu&#39;,&nbsp;&#39;Baidu&#39;,&nbsp;&#39;Taobao&#39;,&nbsp;&#39;Runoob&#39;,&nbsp;&#39;Google&#39;,&nbsp;&#39;Facebook&#39;}Runoob&nbsp;在集合中{&#39;b&#39;,&nbsp;&#39;c&#39;,&nbsp;&#39;a&#39;,&nbsp;&#39;r&#39;,&nbsp;&#39;d&#39;}{&#39;r&#39;,&nbsp;&#39;b&#39;,&nbsp;&#39;d&#39;}{&#39;b&#39;,&nbsp;&#39;c&#39;,&nbsp;&#39;a&#39;,&nbsp;&#39;z&#39;,&nbsp;&#39;m&#39;,&nbsp;&#39;r&#39;,&nbsp;&#39;l&#39;,&nbsp;&#39;d&#39;}{&#39;c&#39;,&nbsp;&#39;a&#39;}{&#39;z&#39;,&nbsp;&#39;b&#39;,&nbsp;&#39;m&#39;,&nbsp;&#39;r&#39;,&nbsp;&#39;l&#39;,&nbsp;&#39;d&#39;}</pre><hr/><h2>Dictionary（字典）</h2><p>字典（dictionary）是Python中另一个非常有用的内置数据类型。</p><p>列表是有序的对象集合，字典是无序的对象集合。两者之间的区别在于：字典当中的元素是通过键来存取的，而不是通过偏移存取。</p><p>字典是一种映射类型，字典用 <span class=\"marked\">{ }</span> 标识，它是一个无序的 <strong>键(key) : 值(value)</strong> 的集合。</p><p>键(key)必须使用不可变类型。</p><p>在同一个字典中，键(key)必须是唯一的。</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: #a50\">#!/usr/bin/python3</span><br/><br/><span style=\"color: Teal;\">dict</span> <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">{</span><span style=\"color: Olive;\">}</span><br/><span style=\"color: Teal;\">dict</span><span style=\"color: Olive;\">[</span><span style=\"color: #a11;\">&#39;one&#39;</span><span style=\"color: Olive;\">]</span> <span style=\"color: Gray;\">=</span> <span style=\"color: #a11;\">&quot;1 - 菜鸟教程&quot;</span><br/><span style=\"color: Teal;\">dict</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span><span style=\"color: Olive;\">]</span> &nbsp; &nbsp; <span style=\"color: Gray;\">=</span> <span style=\"color: #a11;\">&quot;2 - 菜鸟工具&quot;</span><br/><br/>tinydict <span style=\"color: Gray;\">=</span> <span style=\"color: Olive;\">{</span><span style=\"color: #a11;\">&#39;name&#39;</span>: <span style=\"color: #a11;\">&#39;runoob&#39;</span><span style=\"color: Gray;\">,</span><span style=\"color: #a11;\">&#39;code&#39;</span>:<span style=\"color: Maroon;\">1</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;site&#39;</span>: <span style=\"color: #a11;\">&#39;www.runoob.com&#39;</span><span style=\"color: Olive;\">}</span><br/><br/><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">dict</span><span style=\"color: Olive;\">[</span><span style=\"color: #a11;\">&#39;one&#39;</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 输出键为 &#39;one&#39; 的值</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span><span style=\"color: Teal;\">dict</span><span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">2</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; <span style=\"color: #a50\"># 输出键为 2 的值</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>tinydict<span style=\"color: Olive;\">)</span> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;<span style=\"color: #a50\"># 输出完整的字典</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>tinydict.<span style=\"color: #05a;\">keys</span><span style=\"color: Olive;\">(</span><span style=\"color: Olive;\">)</span><span style=\"color: Olive;\">)</span> &nbsp; <span style=\"color: #a50\"># 输出所有键</span><br/><span style=\"color: Green;font-weight:bold;\">print</span> <span style=\"color: Olive;\">(</span>tinydict.<span style=\"color: #05a;\">values</span><span style=\"color: Olive;\">(</span><span style=\"color: Olive;\">)</span><span style=\"color: Olive;\">)</span> <span style=\"color: #a50\"># 输出所有值</span><br/></div></div><p>以上实例输出结果：</p><pre class=\"prettyprint prettyprinted\" style=\"\">1&nbsp;-&nbsp;菜鸟教程2&nbsp;-&nbsp;菜鸟工具{&#39;name&#39;:&nbsp;&#39;runoob&#39;,&nbsp;&#39;code&#39;:&nbsp;1,&nbsp;&#39;site&#39;:&nbsp;&#39;www.runoob.com&#39;}dict_keys([&#39;name&#39;,&nbsp;&#39;code&#39;,&nbsp;&#39;site&#39;])dict_values([&#39;runoob&#39;,&nbsp;1,&nbsp;&#39;www.runoob.com&#39;])</pre><p>构造函数 dict() 可以直接从键值对序列中构建字典如下：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Teal;\">dict</span><span style=\"color: Olive;\">(</span><span style=\"color: Olive;\">[</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;Runoob&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">1</span><span style=\"color: Olive;\">)</span><span style=\"color: Gray;\">,</span> <span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;Google&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">2</span><span style=\"color: Olive;\">)</span><span style=\"color: Gray;\">,</span> <span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&#39;Taobao&#39;</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">)</span><span style=\"color: Olive;\">]</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Olive;\">{</span><span style=\"color: #a11;\">&#39;Runoob&#39;</span>: <span style=\"color: Maroon;\">1</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Google&#39;</span>: <span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Taobao&#39;</span>: <span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">}</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Olive;\">{</span>x: x**<span style=\"color: Maroon;\">2</span> <span style=\"color: Green;font-weight:bold;\">for</span> x <span style=\"color: Green;font-weight:bold;\">in</span> <span style=\"color: Olive;\">(</span><span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">4</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">6</span><span style=\"color: Olive;\">)</span><span style=\"color: Olive;\">}</span><br/><span style=\"color: Olive;\">{</span><span style=\"color: Maroon;\">2</span>: <span style=\"color: Maroon;\">4</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">4</span>: <span style=\"color: Maroon;\">16</span><span style=\"color: Gray;\">,</span> <span style=\"color: Maroon;\">6</span>: <span style=\"color: Maroon;\">36</span><span style=\"color: Olive;\">}</span><br/><span style=\"color: Gray;\">&gt;&gt;&gt;</span> <span style=\"color: Teal;\">dict</span><span style=\"color: Olive;\">(</span>Runoob<span style=\"color: Gray;\">=</span><span style=\"color: Maroon;\">1</span><span style=\"color: Gray;\">,</span> Google<span style=\"color: Gray;\">=</span><span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> Taobao<span style=\"color: Gray;\">=</span><span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">)</span><br/><span style=\"color: Olive;\">{</span><span style=\"color: #a11;\">&#39;Runoob&#39;</span>: <span style=\"color: Maroon;\">1</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Google&#39;</span>: <span style=\"color: Maroon;\">2</span><span style=\"color: Gray;\">,</span> <span style=\"color: #a11;\">&#39;Taobao&#39;</span>: <span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">}</span><br/></div></div><p><span class=\"marked\">{x: x**2 for x in (2, 4, 6)}</span> 该代码使用的是字典推导式，更多推导式内容可以参考：<a href=\"https://www.runoob.com/python3/python-comprehensions.html\" target=\"_blank\">Python 推导式</a>。</p><p>另外，字典类型也有一些内置的函数，例如 clear()、keys()、values() 等。</p><p><strong>注意：</strong></p><ul class=\" list-paddingleft-2\"><li><p>1、字典是一种映射类型，它的元素是键值对。</p></li><li><p>2、字典的关键字必须为不可变类型，且不能重复。</p></li><li><p>3、创建空字典使用 <strong>{ }</strong>。</p></li></ul><hr/><h2>bytes 类型</h2><p>在 Python3 中，bytes 类型表示的是不可变的二进制序列（byte sequence）。</p><p>与字符串类型不同的是，bytes 类型中的元素是整数值（0 到 255 之间的整数），而不是 Unicode 字符。</p><p>bytes 类型通常用于处理二进制数据，比如图像文件、音频文件、视频文件等等。在网络编程中，也经常使用 bytes 类型来传输二进制数据。</p><p>创建 bytes 对象的方式有多种，最常见的方式是使用 b 前缀：</p><p>此外，也可以使用 bytes() 函数将其他类型的对象转换为 bytes 类型。bytes() 函数的第一个参数是要转换的对象，第二个参数是编码方式，如果省略第二个参数，则默认使用 UTF-8 编码：</p><pre class=\"prettyprint prettyprinted\" style=\"\">x&nbsp;=&nbsp;bytes(&quot;hello&quot;,&nbsp;encoding=&quot;utf-8&quot;)</pre><p>与字符串类型类似，bytes 类型也支持许多操作和方法，如切片、拼接、查找、替换等等。同时，由于 bytes 类型是不可变的，因此在进行修改操作时需要创建一个新的 bytes 对象。例如：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\"><br/>x <span style=\"color: Gray;\">=</span> b<span style=\"color: #a11;\">&quot;hello&quot;</span><br/>y <span style=\"color: Gray;\">=</span> x<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">1</span>:<span style=\"color: Maroon;\">3</span><span style=\"color: Olive;\">]</span> &nbsp;<span style=\"color: #a50\"># 切片操作，得到 b&quot;el&quot;</span><br/>z <span style=\"color: Gray;\">=</span> x + b<span style=\"color: #a11;\">&quot;world&quot;</span> &nbsp;<span style=\"color: #a50\"># 拼接操作，得到 b&quot;helloworld&quot;</span><br/></div></div><p>需要注意的是，bytes 类型中的元素是整数值，因此在进行比较操作时需要使用相应的整数值。例如：</p><div class=\"example\"><h2 class=\"example\">实例</h2><div class=\"example_code\">x <span style=\"color: Gray;\">=</span> b<span style=\"color: #a11;\">&quot;hello&quot;</span><br/><span style=\"color: Green;font-weight:bold;\">if</span> x<span style=\"color: Olive;\">[</span><span style=\"color: Maroon;\">0</span><span style=\"color: Olive;\">]</span> <span style=\"color: Gray;\">==</span> <span style=\"color: Teal;\">ord</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&quot;h&quot;</span><span style=\"color: Olive;\">)</span>:<br/>&nbsp; &nbsp; <span style=\"color: Green;font-weight:bold;\">print</span><span style=\"color: Olive;\">(</span><span style=\"color: #a11;\">&quot;The first element is &#39;h&#39;&quot;</span><span style=\"color: Olive;\">)</span><br/></div></div><p>其中 ord() 函数用于将字符转换为相应的整数值。</p><hr/><h2>Python数据类型转换</h2><p>有时候，我们需要对数据内置的类型进行转换，数据类型的转换，你只需要将数据类型作为函数名即可，在下一章节 <a href=\"https://www.runoob.com/python3/python3-type-conversion.html\" target=\"_blank\">Python3 数据类型转换</a> 会具体介绍。</p><p>以下几个内置的函数可以执行数据类型之间的转换。这些函数返回一个新的对象，表示转换的值。</p><table class=\"reference\"><tbody><tr class=\"firstRow\"><th>函数</th><th>描述</th></tr><tr valign=\"top\"><td><p><a href=\"python-func-int.html\" target=\"_blank\">int(x [,base])</a></p></td><td><p>将x转换为一个整数</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-float.html\" target=\"_blank\">float(x)</a></p></td><td><p>将x转换到一个浮点数</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-complex.html\" target=\"_blank\">complex(real [,imag])</a></p></td><td><p>创建一个复数</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-str.html\" target=\"_blank\">str(x)</a></p></td><td><p>将对象 x 转换为字符串</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-repr.html\" target=\"_blank\">repr(x)</a></p></td><td><p>将对象 x 转换为表达式字符串</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-eval.html\" target=\"_blank\">eval(str)</a></p></td><td><p>用来计算在字符串中的有效Python表达式,并返回一个对象</p></td></tr><tr valign=\"top\"><td><p><a href=\"/python3/python3-func-tuple.html\" target=\"_blank\">tuple(s)</a></p></td><td><p>将序列 s 转换为一个元组</p></td></tr><tr valign=\"top\"><td><p><a href=\"python3-att-list-list.html\" target=\"_blank\">list(s)</a></p></td><td><p>将序列 s 转换为一个列表</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-set.html\" target=\"_blank\">set(s)</a></p></td><td><p>转换为可变集合</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-dict.html\" target=\"_blank\">dict(d)</a></p></td><td><p>创建一个字典。d 必须是一个 (key, value)元组序列。</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-frozenset.html\" target=\"_blank\">frozenset(s)</a></p></td><td><p>转换为不可变集合</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-chr.html\" target=\"_blank\">chr(x)</a></p></td><td><p>将一个整数转换为一个字符</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-ord.html\" target=\"_blank\">ord(x)</a></p></td><td><p>将一个字符转换为它的整数值</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-hex.html\" target=\"_blank\">hex(x)</a></p></td><td><p>将一个整数转换为一个十六进制字符串</p></td></tr><tr valign=\"top\"><td><p><a href=\"python-func-oct.html\" target=\"_blank\">oct(x)</a></p></td><td><p>将一个整数转换为一个八进制字符串</p></td></tr></tbody></table><!-- 其他扩展 --></div></div>',2,1,0);
/*!40000 ALTER TABLE `fa_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_attachment`
--

DROP TABLE IF EXISTS `fa_attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_attachment` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category` varchar(50) DEFAULT '' COMMENT '类别',
  `admin_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '管理员ID',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `url` varchar(255) DEFAULT '' COMMENT '物理路径',
  `imagewidth` varchar(30) DEFAULT '' COMMENT '宽度',
  `imageheight` varchar(30) DEFAULT '' COMMENT '高度',
  `imagetype` varchar(30) DEFAULT '' COMMENT '图片类型',
  `imageframes` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '图片帧数',
  `filename` varchar(100) DEFAULT '' COMMENT '文件名称',
  `filesize` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `mimetype` varchar(100) DEFAULT '' COMMENT 'mime类型',
  `extparam` varchar(255) DEFAULT '' COMMENT '透传数据',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建日期',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `uploadtime` bigint(16) DEFAULT NULL COMMENT '上传时间',
  `storage` varchar(100) NOT NULL DEFAULT 'local' COMMENT '存储位置',
  `sha1` varchar(40) DEFAULT '' COMMENT '文件 sha1编码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COMMENT='附件表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_attachment`
--

LOCK TABLES `fa_attachment` WRITE;
/*!40000 ALTER TABLE `fa_attachment` DISABLE KEYS */;
INSERT INTO `fa_attachment` VALUES (1,'',1,0,'/assets/img/qrcode.png','150','150','png',0,'qrcode.png',21859,'image/png','',1491635035,1491635035,1491635035,'local','17163603d0263e4838b9387ff2cd4877e8b018f6'),(2,'',1,0,'/uploads/20240322/2b6420feee54317d87962fb3f53aaa0e.png','3556','2000','png',0,'06巧用工具辅助程序学习_00.png',7418847,'image/png','',1711084587,1711084587,1711084587,'local','b3a87eaab859445f61de003ccdec339b236e28c7'),(3,'',1,0,'/uploads/20240322/37fd3c824cd338329d9a58f798b7febb.png','3556','2000','png',0,'06巧用工具辅助程序学习_01.png',4732906,'image/png','',1711084588,1711084588,1711084588,'local','57d34e1e83f78efb46153f6292316aa6554daa43'),(4,'',1,0,'/uploads/20240322/f880a05282bd0243988628c2c0f33d51.png','3556','2000','png',0,'06巧用工具辅助程序学习_02.png',2124982,'image/png','',1711084589,1711084589,1711084589,'local','29ee033b5171c4db1dec425742b92b896f0f1aa7'),(5,'',1,0,'/uploads/20240322/f3ec3a7b401fae04b6521ebcef94710b.png','3556','2000','png',0,'06巧用工具辅助程序学习_03.png',1591556,'image/png','',1711084589,1711084589,1711084589,'local','f4a94f9139276f6ee638a581a494caa9f417a2c9'),(6,'',1,0,'/uploads/20240322/0dc9c68ddcfe8898797858f772edc622.png','3556','2000','png',0,'06巧用工具辅助程序学习_04.png',1090764,'image/png','',1711084590,1711084590,1711084590,'local','6a2503789829473d7507860cac41c03f287adc7f'),(7,'',1,0,'/uploads/20240322/6fe9d9dd6f68fa378fee46777820859e.png','3556','2000','png',0,'06巧用工具辅助程序学习_05.png',1819110,'image/png','',1711084590,1711084590,1711084590,'local','abb648df3a8d6257e43b7456e7b27182c5066655'),(8,'',1,0,'/uploads/20240322/ff3e019a71c5f5b13d15a62bb7149123.png','3556','2000','png',0,'06巧用工具辅助程序学习_06.png',1604814,'image/png','',1711084591,1711084591,1711084591,'local','57b2d54c6f18bc0aff9f85afe05b74ceebf00b8c'),(9,'',1,0,'/uploads/20240322/6154f502e86e47a1bd28e608128037bc.png','3556','2000','png',0,'06巧用工具辅助程序学习_07.png',300610,'image/png','',1711084591,1711084591,1711084591,'local','c266ece72278126c55c22fed4cdf9947e8ed0a13'),(10,'',1,0,'/uploads/20240322/4c5ad7186d0e94a32037cb7ae292c919.png','3556','2000','png',0,'06巧用工具辅助程序学习_08.png',1214716,'image/png','',1711084591,1711084591,1711084591,'local','f654346846cfd16d8a8752f510bc8c745279a886'),(11,'',1,0,'/uploads/20240322/e9aa08958cbe8e3bf083aceeae3f0f45.png','3556','2000','png',0,'06巧用工具辅助程序学习_09.png',845226,'image/png','',1711084592,1711084592,1711084592,'local','2fc836034a281fb934fda9da5835764010fd314e'),(12,'',1,0,'/uploads/20240322/e5d51126cd40f9eec6262ada4c71cbec.png','3556','2000','png',0,'06巧用工具辅助程序学习_10.png',235883,'image/png','',1711084592,1711084592,1711084592,'local','e3f76b98c4f6d066cc4dd604050717ab0f9d66d4'),(13,'',1,0,'/uploads/20240322/38f6b3372dffb0cf18caa5d72d6e89d4.png','3556','2000','png',0,'06巧用工具辅助程序学习_11.png',466836,'image/png','',1711084592,1711084592,1711084592,'local','45911d1714cdd97925ba88aa47221ef1074aa9dd'),(14,'',1,0,'/uploads/20240322/77582f29186d9c554a0808b5581d78a4.png','2560','1440','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_01(1).png',473088,'image/png','',1711086273,1711086273,1711086273,'local','86b3b94440b0a5bcec1f2ae5bad4e4a0f10bc8f0'),(15,'',1,0,'/uploads/20240322/d5a4582608bb4d35897a1fa16015bd3b.png','2560','1440','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_05.png',544316,'image/png','',1711086273,1711086273,1711086273,'local','e40ed6d530a2ecf8451791bfd082022a057716d8'),(16,'',1,0,'/uploads/20240322/29c28b5240d069defaa9ba2816cefed7.png','2560','1440','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_04(1).png',625295,'image/png','',1711086273,1711086273,1711086273,'local','a33a226c9d2d0dfb247a588500d8e8a7be38c1a8'),(17,'',1,0,'/uploads/20240322/55a585da990b90f6d816d689e488af06.png','2560','1440','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_00(1).png',1366474,'image/png','',1711086273,1711086273,1711086273,'local','8aa0fe4ed045e6d578da1c17ace889d41cd888c7'),(18,'',1,0,'/uploads/20240322/a9f198896bc101b825ac63a9de3d879c.png','2560','1440','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_03(1).png',210254,'image/png','',1711086273,1711086273,1711086273,'local','9bae174b824b7d31e724899693e350f90e18737d'),(19,'',1,0,'/uploads/20240322/7c9008e18045e5b9d6d3984d28cf6285.png','2560','1440','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_02(1).png',1523641,'image/png','',1711086274,1711086274,1711086274,'local','8de34bb3c741add55e456e240227c703ff6025f0'),(20,'',1,0,'/uploads/20240322/b069c54d205bd5f986b420179aa15d63.png','2560','1440','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_06.png',562748,'image/png','',1711086274,1711086274,1711086274,'local','804f41d56de78cc42a8c8454a482d3bec32d5d4f'),(21,'',1,0,'/uploads/20240322/6f9d82dc7290afa69932f9019dc8730c.png','10667','6000','png',0,'07利用顺序结构描述问题求解过程--爬取天气网页元素_02.png',6663030,'image/png','',1711086276,1711086276,1711086276,'local','701e3f59f14ff149438db73c590c4a5f3a724e85'),(22,'',1,0,'/uploads/20240322/f6912cd1ec53f99aa2971d839b32fcf0.mkv','','','mkv',0,'2023-11-25 13-06-11.mkv',4241644,'video/x-matroska','',1711102882,1711102882,1711102882,'local','88077db5ee7451c5bb0ee110cf2570fc7929e71d'),(23,'',1,0,'/uploads/20240322/df3e567d6f16d040326c7a0ea29a4f41.gif','1','1','gif',0,'spacer.gif',43,'image/gif','',1711103043,1711103043,1711103043,'local','ea7df583983133b62712b5e73bffbcd45cc53736'),(24,'',1,0,'/uploads/20240322/a5b9072af97a846e2e23f9a472c1ca21.mp4','','','mp4',0,'2023-11-25 13-06-11.mp4',808356,'video/mp4','',1711103591,1711103591,1711103591,'local','c0932b7ecaa27f797557f52c39cc91eda1f79ad6'),(25,'',1,0,'/uploads/20240322/705af6d24089d3df614daac19d948550.xlsx','','','xlsx',0,'2024年春季学期高一年级校本课程公示表.xlsx',16234,'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','',1711104250,1711104250,1711104250,'local','083756f416be7e251d5abb0f1a87e22092708fa1');
/*!40000 ALTER TABLE `fa_attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_auth_group`
--

DROP TABLE IF EXISTS `fa_auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_auth_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父组别',
  `name` varchar(100) DEFAULT '' COMMENT '组名',
  `rules` text NOT NULL COMMENT '规则ID',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='分组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_auth_group`
--

LOCK TABLES `fa_auth_group` WRITE;
/*!40000 ALTER TABLE `fa_auth_group` DISABLE KEYS */;
INSERT INTO `fa_auth_group` VALUES (1,0,'Admin group','*',1491635035,1491635035,'normal'),(2,1,'Second group','13,14,16,15,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,40,41,42,43,44,45,46,47,48,49,50,55,56,57,58,59,60,61,62,63,64,65,1,9,10,11,7,6,8,2,4,5',1491635035,1491635035,'normal'),(3,2,'Third group','1,4,9,10,11,13,14,15,16,17,40,41,42,43,44,45,46,47,48,49,50,55,56,57,58,59,60,61,62,63,64,65,5',1491635035,1491635035,'normal'),(4,1,'Second group 2','1,4,13,14,15,16,17,55,56,57,58,59,60,61,62,63,64,65',1491635035,1491635035,'normal'),(5,2,'Third group 2','1,2,6,7,8,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34',1491635035,1491635035,'normal');
/*!40000 ALTER TABLE `fa_auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_auth_group_access`
--

DROP TABLE IF EXISTS `fa_auth_group_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '会员ID',
  `group_id` int(10) unsigned NOT NULL COMMENT '级别ID',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='权限分组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_auth_group_access`
--

LOCK TABLES `fa_auth_group_access` WRITE;
/*!40000 ALTER TABLE `fa_auth_group_access` DISABLE KEYS */;
INSERT INTO `fa_auth_group_access` VALUES (1,1),(2,1);
/*!40000 ALTER TABLE `fa_auth_group_access` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_auth_rule`
--

DROP TABLE IF EXISTS `fa_auth_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('menu','file') NOT NULL DEFAULT 'file' COMMENT 'menu为菜单,file为权限节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(100) DEFAULT '' COMMENT '规则名称',
  `title` varchar(50) DEFAULT '' COMMENT '规则名称',
  `icon` varchar(50) DEFAULT '' COMMENT '图标',
  `url` varchar(255) DEFAULT '' COMMENT '规则URL',
  `condition` varchar(255) DEFAULT '' COMMENT '条件',
  `remark` varchar(255) DEFAULT '' COMMENT '备注',
  `ismenu` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否为菜单',
  `menutype` enum('addtabs','blank','dialog','ajax') DEFAULT NULL COMMENT '菜单类型',
  `extend` varchar(255) DEFAULT '' COMMENT '扩展属性',
  `py` varchar(30) DEFAULT '' COMMENT '拼音首字母',
  `pinyin` varchar(100) DEFAULT '' COMMENT '拼音',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `pid` (`pid`),
  KEY `weigh` (`weigh`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8mb4 COMMENT='节点表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_auth_rule`
--

LOCK TABLES `fa_auth_rule` WRITE;
/*!40000 ALTER TABLE `fa_auth_rule` DISABLE KEYS */;
INSERT INTO `fa_auth_rule` VALUES (1,'file',0,'dashboard','控制台','fa fa-dashboard','','','用于展示当前系统中的统计数据、统计报表及重要实时数据',1,'addtabs','','kzt','kongzhitai',1491635035,1699675561,999999,'normal'),(2,'file',0,'general','常规管理','fa fa-cogs','','','',1,'addtabs','','cggl','changguiguanli',1491635035,1711172505,1110,'normal'),(3,'file',111,'category','分类管理','fa fa-leaf','','','分类类型请在常规管理->系统配置->字典配置中添加',1,'addtabs','','flgl','fenleiguanli',1491635035,1711172469,0,'normal'),(4,'file',0,'addon','插件管理','fa fa-rocket','','','可在线安装、卸载、禁用、启用、配置、升级插件，插件升级前请做好备份。',1,'addtabs','','cjgl','chajianguanli',1491635035,1722004014,0,'normal'),(5,'file',0,'auth','权限管理','fa fa-group','','','',1,'addtabs','','qxgl','quanxianguanli',1491635035,1721748955,-1,'normal'),(6,'file',2,'general/config','Config','fa fa-cog','','','Config tips',1,NULL,'','xtpz','xitongpeizhi',1491635035,1491635035,60,'normal'),(7,'file',2,'general/attachment','Attachment','fa fa-file-image-o','','','Attachment tips',1,NULL,'','fjgl','fujianguanli',1491635035,1491635035,53,'normal'),(8,'file',2,'general/profile','Profile','fa fa-user','','','',1,NULL,'','grzl','gerenziliao',1491635035,1491635035,34,'normal'),(9,'file',5,'auth/admin','Admin','fa fa-user','','','Admin tips',1,NULL,'','glygl','guanliyuanguanli',1491635035,1491635035,118,'normal'),(10,'file',5,'auth/adminlog','Admin log','fa fa-list-alt','','','Admin log tips',1,NULL,'','glyrz','guanliyuanrizhi',1491635035,1491635035,113,'normal'),(11,'file',5,'auth/group','Group','fa fa-group','','','Group tips',1,NULL,'','jsz','juesezu',1491635035,1491635035,109,'normal'),(12,'file',5,'auth/rule','Rule','fa fa-bars','','','Rule tips',1,NULL,'','cdgz','caidanguize',1491635035,1491635035,104,'normal'),(13,'file',1,'dashboard/index','View','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,136,'normal'),(14,'file',1,'dashboard/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,135,'normal'),(15,'file',1,'dashboard/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,133,'normal'),(16,'file',1,'dashboard/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,134,'normal'),(17,'file',1,'dashboard/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,132,'normal'),(18,'file',6,'general/config/index','View','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,52,'normal'),(19,'file',6,'general/config/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,51,'normal'),(20,'file',6,'general/config/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,50,'normal'),(21,'file',6,'general/config/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,49,'normal'),(22,'file',6,'general/config/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,48,'normal'),(23,'file',7,'general/attachment/index','View','fa fa-circle-o','','','Attachment tips',0,NULL,'','','',1491635035,1491635035,59,'normal'),(24,'file',7,'general/attachment/select','Select attachment','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,58,'normal'),(25,'file',7,'general/attachment/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,57,'normal'),(26,'file',7,'general/attachment/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,56,'normal'),(27,'file',7,'general/attachment/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,55,'normal'),(28,'file',7,'general/attachment/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,54,'normal'),(29,'file',8,'general/profile/index','View','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,33,'normal'),(30,'file',8,'general/profile/update','Update profile','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,32,'normal'),(31,'file',8,'general/profile/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,31,'normal'),(32,'file',8,'general/profile/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,30,'normal'),(33,'file',8,'general/profile/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,29,'normal'),(34,'file',8,'general/profile/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,28,'normal'),(35,'file',3,'category/index','View','fa fa-circle-o','','','Category tips',0,NULL,'','','',1491635035,1491635035,142,'normal'),(36,'file',3,'category/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,141,'normal'),(37,'file',3,'category/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,140,'normal'),(38,'file',3,'category/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,139,'normal'),(39,'file',3,'category/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,138,'normal'),(40,'file',9,'auth/admin/index','View','fa fa-circle-o','','','Admin tips',0,NULL,'','','',1491635035,1491635035,117,'normal'),(41,'file',9,'auth/admin/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,116,'normal'),(42,'file',9,'auth/admin/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,115,'normal'),(43,'file',9,'auth/admin/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,114,'normal'),(44,'file',10,'auth/adminlog/index','View','fa fa-circle-o','','','Admin log tips',0,NULL,'','','',1491635035,1491635035,112,'normal'),(45,'file',10,'auth/adminlog/detail','Detail','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,111,'normal'),(46,'file',10,'auth/adminlog/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,110,'normal'),(47,'file',11,'auth/group/index','View','fa fa-circle-o','','','Group tips',0,NULL,'','','',1491635035,1491635035,108,'normal'),(48,'file',11,'auth/group/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,107,'normal'),(49,'file',11,'auth/group/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,106,'normal'),(50,'file',11,'auth/group/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,105,'normal'),(51,'file',12,'auth/rule/index','View','fa fa-circle-o','','','Rule tips',0,NULL,'','','',1491635035,1491635035,103,'normal'),(52,'file',12,'auth/rule/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,102,'normal'),(53,'file',12,'auth/rule/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,101,'normal'),(54,'file',12,'auth/rule/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,100,'normal'),(55,'file',4,'addon/index','View','fa fa-circle-o','','','Addon tips',0,NULL,'','','',1491635035,1491635035,0,'normal'),(56,'file',4,'addon/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(57,'file',4,'addon/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(58,'file',4,'addon/del','Delete','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(59,'file',4,'addon/downloaded','Local addon','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(60,'file',4,'addon/state','Update state','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(63,'file',4,'addon/config','Setting','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(64,'file',4,'addon/refresh','Refresh','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(65,'file',4,'addon/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(66,'file',0,'user','人员管理','fa fa-user-circle','','','',1,'addtabs','','rygl','renyuanguanli',1491635035,1721526098,110,'normal'),(67,'file',66,'user/user','学生管理','fa fa-user','','','',1,'addtabs','','xsgl','xueshengguanli',1491635035,1721526107,0,'normal'),(68,'file',67,'user/user/index','View','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(69,'file',67,'user/user/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(70,'file',67,'user/user/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(71,'file',67,'user/user/del','Del','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(72,'file',67,'user/user/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(73,'file',66,'user/group','班级管理','fa fa-users','','','',1,'addtabs','','bjgl','banjiguanli',1491635035,1721526116,0,'normal'),(74,'file',73,'user/group/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(75,'file',73,'user/group/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(76,'file',73,'user/group/index','View','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(77,'file',73,'user/group/del','Del','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(78,'file',73,'user/group/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(79,'file',66,'user/rule','用户规则','fa fa-circle-o','','','',1,'addtabs','','yhgz','yonghuguize',1491635035,1721526214,0,'hidden'),(80,'file',79,'user/rule/index','View','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(81,'file',79,'user/rule/del','Del','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(82,'file',79,'user/rule/add','Add','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(83,'file',79,'user/rule/edit','Edit','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(84,'file',79,'user/rule/multi','Multi','fa fa-circle-o','','','',0,NULL,'','','',1491635035,1491635035,0,'normal'),(85,'file',0,'test','测试管理','fa fa-circle-o','','','',1,'addtabs','','csgl','ceshiguanli',1696755890,1711172549,0,'hidden'),(86,'file',85,'test/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1696755890,1696755890,0,'normal'),(87,'file',85,'test/recyclebin','回收站','fa fa-circle-o','','','',0,NULL,'','hsz','huishouzhan',1696755890,1696755890,0,'normal'),(88,'file',85,'test/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1696755890,1696755890,0,'normal'),(89,'file',85,'test/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1696755890,1696755890,0,'normal'),(90,'file',85,'test/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1696755890,1696755890,0,'normal'),(91,'file',85,'test/destroy','真实删除','fa fa-circle-o','','','',0,NULL,'','zssc','zhenshishanchu',1696755890,1696755890,0,'normal'),(92,'file',85,'test/restore','还原','fa fa-circle-o','','','',0,NULL,'','hy','huanyuan',1696755890,1696755890,0,'normal'),(93,'file',85,'test/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1696755890,1696755890,0,'normal'),(97,'file',0,'command','在线命令管理','fa fa-terminal','','','',1,'addtabs','','zxmlgl','zaixianminglingguanli',1699347324,1721748898,0,'hidden'),(98,'file',97,'command/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1699347324,1699347324,0,'normal'),(99,'file',97,'command/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1699347324,1699347324,0,'normal'),(100,'file',97,'command/detail','详情','fa fa-circle-o','','','',0,NULL,'','xq','xiangqing',1699347324,1699347324,0,'normal'),(101,'file',97,'command/command','生成并执行命令','fa fa-circle-o','','','',0,NULL,'','scbzxml','shengchengbingzhixingmingling',1699347324,1699347324,0,'normal'),(102,'file',97,'command/execute','再次执行命令','fa fa-circle-o','','','',0,NULL,'','zczxml','zaicizhixingmingling',1699347324,1699347324,0,'normal'),(103,'file',97,'command/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1699347324,1699347324,0,'normal'),(104,'file',97,'command/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1699347324,1699347324,0,'normal'),(105,'file',111,'article','文章管理','fa fa-circle-o','','','',1,'addtabs','','wzgl','wenzhangguanli',1699347688,1711172492,10,'normal'),(106,'file',105,'article/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1699347688,1710594836,0,'normal'),(107,'file',105,'article/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1699347688,1710594836,0,'normal'),(108,'file',105,'article/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1699347688,1710594836,0,'normal'),(109,'file',105,'article/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1699347688,1710594836,0,'normal'),(110,'file',105,'article/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1699347688,1710594836,0,'normal'),(111,'file',0,'contents','内容管理','fa fa-envira','','','',1,'addtabs','','nrgl','neirongguanli',1699347747,1711172621,0,'normal'),(112,'file',124,'grade','年级管理','fa fa-th-list','','','',1,'addtabs','','njgl','nianjiguanli',1699669569,1710233454,0,'hidden'),(113,'file',112,'grade/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1699669569,1699669742,0,'normal'),(114,'file',112,'grade/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1699669569,1699669742,0,'normal'),(115,'file',112,'grade/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1699669569,1699669742,0,'normal'),(116,'file',112,'grade/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1699669569,1699669742,0,'normal'),(117,'file',112,'grade/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1699669569,1699669742,0,'normal'),(118,'file',124,'classs','班级管理','fa fa-navicon','','','',1,'addtabs','','bjgl','banjiguanli',1699670147,1710469293,0,'hidden'),(119,'file',118,'classs/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1699670147,1699684779,0,'normal'),(120,'file',118,'classs/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1699670147,1699684779,0,'normal'),(121,'file',118,'classs/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1699670147,1699684779,0,'normal'),(122,'file',118,'classs/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1699670147,1699684779,0,'normal'),(123,'file',118,'classs/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1699670147,1699684779,0,'normal'),(124,'file',0,'teach','教学管理','fa fa-graduation-cap','','','',1,'addtabs','','jxgl','jiaoxueguanli',1699670272,1704963991,111,'normal'),(125,'file',2,'fastaddc111','一键添加','fa fa-check-square','','','',1,'addtabs','','yjtj','yijiantianjia',1699675513,1710563132,0,'hidden'),(132,'file',124,'signin','签到管理','fa fa-circle-o','','','',1,'addtabs','','qdgl','qiandaoguanli',1704186247,1710496847,110,'normal'),(133,'file',132,'signin/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1704186247,1710497552,0,'normal'),(134,'file',132,'signin/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1704186247,1710497552,0,'normal'),(135,'file',132,'signin/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1704186247,1710497552,0,'normal'),(136,'file',132,'signin/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1704186247,1710497552,0,'normal'),(137,'file',132,'signin/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1704186247,1710497552,0,'normal'),(138,'file',0,'gethydro','Gethydro','fa fa-circle-o','','','',1,'addtabs','','G','Gethydro',1704705417,1711172565,0,'hidden'),(139,'file',124,'authcode','注册码','fa fa-circle-o','','','',1,'addtabs','','zcm','zhucema',1710233667,1710234532,4,'normal'),(140,'file',139,'authcode/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1710233667,1710234049,0,'normal'),(141,'file',139,'authcode/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1710233667,1710234049,0,'normal'),(142,'file',139,'authcode/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1710233667,1710234049,0,'normal'),(143,'file',139,'authcode/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1710233667,1710234049,0,'normal'),(144,'file',139,'authcode/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1710233667,1710234049,0,'normal'),(157,'file',124,'signinrecord/php','签到记录','fa fa-circle-o','','','',1,'addtabs','','qdjl','qiandaojilu',1710566997,1711443684,55,'hidden'),(158,'file',157,'signinrecord/php/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1710566997,1710566997,0,'normal'),(159,'file',157,'signinrecord/php/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1710566997,1710566997,0,'normal'),(160,'file',157,'signinrecord/php/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1710566997,1710566997,0,'normal'),(161,'file',157,'signinrecord/php/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1710566997,1710566997,0,'normal'),(162,'file',157,'signinrecord/php/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1710566997,1710566997,0,'normal'),(163,'file',187,'taskrecord','编译记录','fa fa-circle-o','','','',1,'addtabs','','byjl','bianyijilu',1711110279,1716966207,0,'normal'),(164,'file',163,'taskrecord/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1711110279,1711176831,0,'normal'),(165,'file',163,'taskrecord/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1711110279,1711176831,0,'normal'),(166,'file',163,'taskrecord/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1711110279,1711176831,0,'normal'),(167,'file',163,'taskrecord/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1711110279,1711176832,0,'normal'),(168,'file',163,'taskrecord/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1711110279,1711176832,0,'normal'),(169,'file',124,'questioning','提问管理','fa fa-circle-o','','','',1,'addtabs','','twgl','tiwenguanli',1716965448,1716965496,99,'normal'),(170,'file',169,'questioning/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1716965448,1716965448,0,'normal'),(171,'file',169,'questioning/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1716965448,1716965448,0,'normal'),(172,'file',169,'questioning/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1716965448,1716965448,0,'normal'),(173,'file',169,'questioning/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1716965448,1716965448,0,'normal'),(174,'file',169,'questioning/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1716965448,1716965448,0,'normal'),(175,'file',124,'studytask','学习任务','fa fa-circle-o','','','',1,'addtabs','','xxrw','xuexirenwu',1716965689,1716965851,1110,'normal'),(176,'file',175,'studytask/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1716965689,1716965689,0,'normal'),(177,'file',175,'studytask/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1716965689,1716965689,0,'normal'),(178,'file',175,'studytask/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1716965689,1716965689,0,'normal'),(179,'file',175,'studytask/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1716965689,1716965689,0,'normal'),(180,'file',175,'studytask/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1716965689,1716965689,0,'normal'),(181,'file',187,'studytaskrecord','学习任务记录','fa fa-circle-o','','','',1,'addtabs','','xxrwjl','xuexirenwujilu',1716966117,1716966218,0,'normal'),(182,'file',181,'studytaskrecord/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1716966117,1716985489,0,'normal'),(183,'file',181,'studytaskrecord/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1716966117,1716985489,0,'normal'),(184,'file',181,'studytaskrecord/edit','编辑','fa fa-circle-o','','','',0,NULL,'','bj','bianji',1716966117,1716985489,0,'normal'),(185,'file',181,'studytaskrecord/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1716966117,1716985489,0,'normal'),(186,'file',181,'studytaskrecord/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1716966117,1716985489,0,'normal'),(187,'file',0,'records','记录中心','fa fa-database','','','',1,'addtabs','','jlzx','jiluzhongxin',1716966195,1716966195,0,'normal'),(188,'file',0,'version','版本管理','fa fa-file-text-o','','','常用于管理移动端应用版本更新',1,NULL,'','bbgl','banbenguanli',1721720024,1721720024,0,'hidden'),(189,'file',188,'version/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1721720024,1721720024,0,'hidden'),(190,'file',188,'version/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1721720024,1721720024,0,'hidden'),(191,'file',188,'version/edit','修改','fa fa-circle-o','','','',0,NULL,'','xg','xiugai',1721720024,1721720024,0,'hidden'),(192,'file',188,'version/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1721720024,1721720024,0,'hidden'),(193,'file',188,'version/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1721720024,1721720024,0,'hidden'),(202,'file',0,'xunsearch','Xunsearch全文搜索管理','fa fa-search','','','',1,NULL,'','Xqwssgl','Xunsearchquanwensousuoguanli',1721738287,1721738287,0,'hidden'),(203,'file',202,'xunsearch/project','项目管理','fa fa-cog','','','',1,NULL,'','xmgl','xiangmuguanli',1721738287,1721738287,0,'hidden'),(204,'file',203,'xunsearch/project/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1721738287,1721738287,0,'hidden'),(205,'file',203,'xunsearch/project/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1721738287,1721738287,0,'hidden'),(206,'file',203,'xunsearch/project/edit','修改','fa fa-circle-o','','','',0,NULL,'','xg','xiugai',1721738287,1721738287,0,'hidden'),(207,'file',203,'xunsearch/project/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1721738287,1721738287,0,'hidden'),(208,'file',203,'xunsearch/project/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1721738287,1721738287,0,'hidden'),(209,'file',203,'xunsearch/project/reset','重置索引','fa fa-circle-o','','','',0,NULL,'','zzsy','zhongzhisuoyin',1721738287,1721738287,0,'hidden'),(210,'file',203,'xunsearch/project/refresh','生成配置','fa fa-circle-o','','','',0,NULL,'','scpz','shengchengpeizhi',1721738287,1721738287,0,'hidden'),(211,'file',203,'xunsearch/project/flush','强制刷新','fa fa-circle-o','','','',0,NULL,'','qzsx','qiangzhishuaxin',1721738287,1721738287,0,'hidden'),(212,'file',203,'xunsearch/project/config','加载配置','fa fa-circle-o','','','',0,NULL,'','jzpz','jiazaipeizhi',1721738287,1721738287,0,'hidden'),(213,'file',202,'xunsearch/fields','字段管理','fa fa-list','','','管理项目索引的字段，如果增加了字段，请确保相应的整合接口有写入该字段数据',0,NULL,'','zdgl','ziduanguanli',1721738287,1721738287,0,'hidden'),(214,'file',213,'xunsearch/fields/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1721738287,1721738287,0,'hidden'),(215,'file',213,'xunsearch/fields/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1721738287,1721738287,0,'hidden'),(216,'file',213,'xunsearch/fields/edit','修改','fa fa-circle-o','','','',0,NULL,'','xg','xiugai',1721738287,1721738287,0,'hidden'),(217,'file',213,'xunsearch/fields/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1721738287,1721738287,0,'hidden'),(218,'file',213,'xunsearch/fields/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1721738287,1721738287,0,'hidden'),(219,'file',202,'xunsearch/logger','搜索词管理','fa fa-list','','','此列表结果由Xunsearch服务记录，提供如果搜索词没有相应的搜索结果，Xunsearch不会记录该记录值',0,NULL,'','sscgl','sousuociguanli',1721738287,1721738287,0,'hidden'),(220,'file',219,'xunsearch/logger/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1721738287,1721738287,0,'hidden'),(221,'file',219,'xunsearch/logger/add','添加','fa fa-circle-o','','','',0,NULL,'','tj','tianjia',1721738287,1721738287,0,'hidden'),(222,'file',219,'xunsearch/logger/edit','修改','fa fa-circle-o','','','',0,NULL,'','xg','xiugai',1721738287,1721738287,0,'hidden'),(223,'file',219,'xunsearch/logger/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1721738287,1721738287,0,'hidden'),(224,'file',219,'xunsearch/logger/multi','批量更新','fa fa-circle-o','','','',0,NULL,'','plgx','pilianggengxin',1721738287,1721738287,0,'hidden'),(225,'file',2,'general/logs','日志管理','fa fa-pied-piper-alt','','','',1,NULL,'','rzgl','rizhiguanli',1721738302,1721738302,0,'normal'),(226,'file',225,'general/logs/index','查看','fa fa-circle-o','','','',0,NULL,'','zk','zhakan',1721738302,1721738302,0,'normal'),(227,'file',225,'general/logs/del','删除','fa fa-circle-o','','','',0,NULL,'','sc','shanchu',1721738302,1721738302,0,'normal'),(228,'file',225,'general/logs/detail','详情','fa fa-circle-o','','','',0,NULL,'','xq','xiangqing',1721738302,1721738302,0,'normal');
/*!40000 ALTER TABLE `fa_auth_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_authcode`
--

DROP TABLE IF EXISTS `fa_authcode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_authcode` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '注册码ID',
  `code` text COMMENT '注册码',
  `classid` int(11) NOT NULL DEFAULT '1' COMMENT '班级ID',
  `isusing` tinyint(1) NOT NULL DEFAULT '1' COMMENT '是否启用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_authcode`
--

LOCK TABLES `fa_authcode` WRITE;
/*!40000 ALTER TABLE `fa_authcode` DISABLE KEYS */;
INSERT INTO `fa_authcode` VALUES (3,'ssfnssfs',3,1),(4,'77777777',4,1),(6,'testee',1,1),(7,'1234566',3,1),(8,'eeeeee',4,1),(9,'nfzx2310',5,1),(10,'testc12!',6,1),(11,'testgr01',7,1),(12,'ceshi111',8,1),(13,'2024nfzx',9,1);
/*!40000 ALTER TABLE `fa_authcode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_category`
--

DROP TABLE IF EXISTS `fa_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `type` varchar(30) DEFAULT '' COMMENT '栏目类型',
  `name` varchar(30) DEFAULT '',
  `nickname` varchar(50) DEFAULT '',
  `flag` set('hot','index','recommend') DEFAULT '',
  `image` varchar(100) DEFAULT '' COMMENT '图片',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `diyname` varchar(30) DEFAULT '' COMMENT '自定义名称',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`),
  KEY `weigh` (`weigh`,`id`),
  KEY `pid` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COMMENT='分类表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_category`
--

LOCK TABLES `fa_category` WRITE;
/*!40000 ALTER TABLE `fa_category` DISABLE KEYS */;
INSERT INTO `fa_category` VALUES (14,0,'article','默认','默认','','','','','',1710594109,1710594109,14,'normal'),(16,0,'article','网页前端教程','网页前端教程','','','','','',1711550155,1711550155,16,'normal'),(17,0,'article','测试','测试','','','','','',1711551742,1711551742,17,'normal'),(18,0,'article','算法学习','算法学习','','','','','',1711636624,1711636624,18,'normal'),(19,0,'article','123','123','','','','','',1715437937,1715437937,19,'normal'),(20,0,'article','Python基础','Python基础','','','','','',1716073846,1716074051,200,'normal');
/*!40000 ALTER TABLE `fa_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_chat`
--

DROP TABLE IF EXISTS `fa_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` text,
  `name` text,
  `userid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_chat`
--

LOCK TABLES `fa_chat` WRITE;
/*!40000 ALTER TABLE `fa_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_class`
--

DROP TABLE IF EXISTS `fa_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(11) DEFAULT NULL COMMENT '班级',
  `headteacher` text COMMENT '班主任(example:詹志坚)',
  `grade` int(11) DEFAULT NULL COMMENT '所属年级(example:2023)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=88 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_class`
--

LOCK TABLES `fa_class` WRITE;
/*!40000 ALTER TABLE `fa_class` DISABLE KEYS */;
INSERT INTO `fa_class` VALUES (46,2301,NULL,2023),(47,2302,NULL,2023),(48,2303,NULL,2023),(49,2304,NULL,2023),(50,2305,NULL,2023),(51,2306,NULL,2023),(52,2307,NULL,2023),(53,2308,NULL,2023),(54,2309,NULL,2023),(55,2310,NULL,2023),(56,2311,NULL,2023),(57,2312,NULL,2023),(58,2313,NULL,2023),(59,2314,NULL,2023),(60,2315,NULL,2023),(61,2316,NULL,2023),(62,2317,NULL,2023),(63,2318,NULL,2023),(64,2319,NULL,2023),(65,2320,NULL,2023),(66,2201,NULL,2022),(67,2202,NULL,2022),(68,2203,NULL,2022),(69,2204,NULL,2022),(70,2205,NULL,2022),(71,2206,NULL,2022),(72,2207,NULL,2022),(73,2208,NULL,2022),(74,2209,NULL,2022),(75,2210,NULL,2022),(76,2211,NULL,2022),(77,2212,NULL,2022),(78,2213,NULL,2022),(79,2214,NULL,2022),(80,2215,NULL,2022),(81,2216,NULL,2022),(82,2217,NULL,2022),(83,2218,NULL,2022),(84,2219,NULL,2022),(85,2220,NULL,2022),(86,2221,NULL,2022),(87,2222,NULL,2022);
/*!40000 ALTER TABLE `fa_class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_command`
--

DROP TABLE IF EXISTS `fa_command`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_command` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `type` varchar(30) NOT NULL DEFAULT '' COMMENT '类型',
  `params` varchar(1500) NOT NULL DEFAULT '' COMMENT '参数',
  `command` varchar(1500) NOT NULL DEFAULT '' COMMENT '命令',
  `content` text COMMENT '返回结果',
  `executetime` bigint(16) unsigned DEFAULT NULL COMMENT '执行时间',
  `createtime` bigint(16) unsigned DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) unsigned DEFAULT NULL COMMENT '更新时间',
  `status` enum('successed','failured') NOT NULL DEFAULT 'failured' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8 COMMENT='在线命令表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_command`
--

LOCK TABLES `fa_command` WRITE;
/*!40000 ALTER TABLE `fa_command` DISABLE KEYS */;
INSERT INTO `fa_command` VALUES (1,'crud','[\"--table=fa_article\"]','php think crud --table=fa_article','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/application/admin/view/article/add.html): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1699347499,1699347499,1699347499,'failured'),(2,'crud','[\"--table=fa_article\"]','php think crud --table=fa_article','controller already exists!\nIf you need to rebuild again, use the parameter --force=true',1699347547,1699347547,1699347547,'failured'),(3,'crud','[\"--table=fa_article\"]','php think crud --table=fa_article','controller already exists!\nIf you need to rebuild again, use the parameter --force=true',1699347563,1699347563,1699347563,'failured'),(4,'crud','[\"--table=fa_article\"]','php think crud --table=fa_article','controller already exists!\nIf you need to rebuild again, use the parameter --force=true',1699347595,1699347595,1699347595,'failured'),(5,'crud','[\"--table=fa_article\"]','php think crud --table=fa_article','controller already exists!\nIf you need to rebuild again, use the parameter --force=true',1699347607,1699347607,1699347607,'failured'),(6,'crud','[\"--force=1\",\"--table=fa_article\"]','php think crud --force=1 --table=fa_article','Build Successed',1699347625,1699347625,1699347625,'successed'),(7,'crud','[\"--force=1\",\"--table=fa_article\"]','php think crud --force=1 --table=fa_article','Build Successed',1699347643,1699347643,1699347643,'successed'),(8,'menu','[\"--controller=Article\"]','php think menu --controller=Article','Build Successed!',1699347688,1699347688,1699347688,'successed'),(9,'crud','[\"--table=fa_grade\"]','php think crud --table=fa_grade','Build Successed',1699669544,1699669544,1699669544,'successed'),(10,'menu','[\"--controller=Grade\"]','php think menu --controller=Grade','Build Successed!',1699669568,1699669568,1699669569,'successed'),(11,'crud','[\"--force=1\",\"--table=fa_grade\"]','php think crud --force=1 --table=fa_grade','Build Successed',1699669707,1699669707,1699669707,'successed'),(12,'menu','[\"--controller=Grade\"]','php think menu --controller=Grade','Build Successed!',1699669711,1699669711,1699669711,'successed'),(13,'crud','[\"--force=1\",\"--table=fa_grade\",\"--fields=grade_id,name,master,introduce\"]','php think crud --force=1 --table=fa_grade --fields=grade_id,name,master,introduce','Build Successed',1699669736,1699669736,1699669736,'successed'),(14,'menu','[\"--controller=Grade\"]','php think menu --controller=Grade','Build Successed!',1699669742,1699669742,1699669742,'successed'),(15,'crud','[\"--table=fa_class\"]','php think crud --table=fa_class','Unable to use internal variable:Class',1699670115,1699670115,1699670115,'failured'),(16,'crud','[\"--table=fa_class\",\"--controller=Classs\"]','php think crud --table=fa_class --controller=Classs','Build Successed',1699670135,1699670135,1699670135,'successed'),(17,'menu','[\"--controller=Classs\"]','php think menu --controller=Classs','Build Successed!',1699670147,1699670147,1699670147,'successed'),(18,'crud','[\"--force=1\",\"--table=fa_class\",\"--controller=Classs\"]','php think crud --force=1 --table=fa_class --controller=Classs','Build Successed',1699670665,1699670665,1699670665,'successed'),(19,'menu','[\"--controller=Classs\"]','php think menu --controller=Classs','Build Successed!',1699670674,1699670674,1699670674,'successed'),(20,'crud','[\"--force=1\",\"--table=fa_class\",\"--controller=Classs\"]','php think crud --force=1 --table=fa_class --controller=Classs','Build Successed',1699673811,1699673811,1699673811,'successed'),(21,'menu','[\"--controller=Classs\"]','php think menu --controller=Classs','Build Successed!',1699673820,1699673820,1699673820,'successed'),(22,'menu','[\"--controller=Fastaddc\"]','php think menu --controller=Fastaddc',NULL,1699675467,1699675467,1699675467,'failured'),(23,'menu','[\"--controller=Fastaddc\"]','php think menu --controller=Fastaddc',NULL,1699675471,1699675471,1699675471,'failured'),(24,'crud','[\"--table=fa_class\",\"--controller=Classs\"]','php think crud --table=fa_class --controller=Classs','model already exists!\nIf you need to rebuild again, use the parameter --force=true',1699684755,1699684755,1699684755,'failured'),(25,'crud','[\"--force=1\",\"--table=fa_class\",\"--controller=Classs\"]','php think crud --force=1 --table=fa_class --controller=Classs','Build Successed',1699684761,1699684761,1699684761,'successed'),(26,'menu','[\"--controller=Classs\"]','php think menu --controller=Classs','Build Successed!',1699684779,1699684779,1699684779,'successed'),(27,'crud','[\"--table=fa_signin_record\"]','php think crud --table=fa_signin_record','Build Successed',1704185372,1704185372,1704185372,'successed'),(28,'crud','[\"--force=1\",\"--table=fa_signin_record\",\"--controller=signin_record\",\"--model=signin_record\"]','php think crud --force=1 --table=fa_signin_record --controller=signin_record --model=signin_record','Build Successed',1704185457,1704185457,1704185457,'successed'),(29,'menu','[\"--controller=Signin_record\"]','php think menu --controller=Signin_record','controller not found',1704185483,1704185483,1704185483,'successed'),(30,'menu','[\"--controller=Signin_record\"]','php think menu --controller=Signin_record','controller not found',1704185499,1704185499,1704185499,'successed'),(31,'crud','[\"--force=1\",\"--table=fa_signin_record\",\"--controller=signinrecord\",\"--model=signinrecord\"]','php think crud --force=1 --table=fa_signin_record --controller=signinrecord --model=signinrecord','Build Successed',1704185525,1704185525,1704185525,'successed'),(32,'menu','[\"--controller=Signinrecord\"]','php think menu --controller=Signinrecord','Build Successed!',1704185538,1704185538,1704185538,'successed'),(33,'crud','[\"--table=fa_signin\"]','php think crud --table=fa_signin','Build Successed',1704186235,1704186235,1704186235,'successed'),(34,'menu','[\"--controller=Signin\"]','php think menu --controller=Signin','Build Successed!',1704186247,1704186247,1704186247,'successed'),(35,'crud','[\"--table=fa_authcode\",\"--fields=code,class_id,isusing\"]','php think crud --table=fa_authcode --fields=code,class_id,isusing','Build Successed',1710233633,1710233633,1710233633,'successed'),(36,'menu','[\"--controller=Authcode\"]','php think menu --controller=Authcode','Build Successed!',1710233667,1710233667,1710233667,'successed'),(37,'crud','[\"--delete=1\",\"--force=1\",\"--table=fa_authcode\",\"--fields=code,class_id,isusing\"]','php think crud --delete=1 --force=1 --table=fa_authcode --fields=code,class_id,isusing','/www/wwwroot/code/public/../application/admin/controller/Authcode.php\n/www/wwwroot/code/public/../application/admin/model/Authcode.php\n/www/wwwroot/code/public/../application/admin/validate/Authcode.php\n/www/wwwroot/code/application/admin/view/authcode/add.html\n/www/wwwroot/code/application/admin/view/authcode/edit.html\n/www/wwwroot/code/application/admin/view/authcode/index.html\n/www/wwwroot/code/application/admin/view/authcode/recyclebin.html\n/www/wwwroot/code/application/admin/lang/zh-cn/authcode.php\n/www/wwwroot/code/public/assets/js/backend/authcode.js\nDelete Successed',1710233714,1710233714,1710233714,'successed'),(38,'crud','[\"--force=1\",\"--table=fa_authcode\",\"--fields=code,class_id,isusing\"]','php think crud --force=1 --table=fa_authcode --fields=code,class_id,isusing','Build Successed',1710233736,1710233736,1710233736,'successed'),(39,'menu','[\"--controller=Authcode\"]','php think menu --controller=Authcode','Build Successed!',1710233762,1710233762,1710233762,'successed'),(40,'crud','[\"--force=1\",\"--table=fa_authcode\",\"--fields=code,classid,isusing\"]','php think crud --force=1 --table=fa_authcode --fields=code,classid,isusing','Build Successed',1710233968,1710233968,1710233968,'successed'),(41,'menu','[\"--controller=Authcode\"]','php think menu --controller=Authcode','Build Successed!',1710233983,1710233983,1710233983,'successed'),(42,'crud','[\"--force=1\",\"--table=fa_authcode\"]','php think crud --force=1 --table=fa_authcode','Build Successed',1710234033,1710234033,1710234033,'successed'),(43,'menu','[\"--controller=Authcode\"]','php think menu --controller=Authcode','Build Successed!',1710234049,1710234049,1710234049,'successed'),(44,'crud','[\"--force=1\",\"--table=fa_signin\"]','php think crud --force=1 --table=fa_signin','Build Successed',1710496992,1710496992,1710496992,'successed'),(45,'crud','[\"--force=1\",\"--table=fa_signin\"]','php think crud --force=1 --table=fa_signin','Build Successed',1710497544,1710497544,1710497544,'successed'),(46,'menu','[\"--controller=Signin\"]','php think menu --controller=Signin','Build Successed!',1710497552,1710497552,1710497552,'successed'),(47,'crud','[\"--force=1\",\"--table=fa_signin_record\"]','php think crud --force=1 --table=fa_signin_record','Build Successed',1710562499,1710562499,1710562499,'successed'),(48,'menu','[\"--controller=Signin_record\"]','php think menu --controller=Signin_record','controller not found',1710562508,1710562508,1710562508,'successed'),(49,'crud','[\"--delete=1\",\"--force=1\",\"--table=fa_signin_record\"]','php think crud --delete=1 --force=1 --table=fa_signin_record','/www/wwwroot/code/public/../application/admin/controller/signin/Record.php\n/www/wwwroot/code/public/../application/admin/model/signin/Record.php\n/www/wwwroot/code/public/../application/admin/validate/signin/Record.php\n/www/wwwroot/code/application/admin/view/signin/record/add.html\n/www/wwwroot/code/application/admin/view/signin/record/edit.html\n/www/wwwroot/code/application/admin/view/signin/record/index.html\n/www/wwwroot/code/application/admin/view/signin/record/recyclebin.html\n/www/wwwroot/code/application/admin/lang/zh-cn/signin/record.php\n/www/wwwroot/code/public/assets/js/backend/signin/record.js\nDelete Successed',1710562543,1710562543,1710562543,'successed'),(50,'crud','[\"--force=1\",\"--table=fa_signin_record\"]','php think crud --force=1 --table=fa_signin_record','Build Successed',1710562545,1710562545,1710562545,'successed'),(51,'menu','[\"--delete=1\",\"--controller=Signinrecord\"]','php think menu --delete=1 --controller=Signinrecord','signinrecord\nsigninrecord/add\nsigninrecord/del\nsigninrecord/edit\nsigninrecord/index\nsigninrecord/multi\nAre you sure you want to delete all those menu?  Type \'yes\' to continue: \nOperation is aborted!',1710562565,1710562565,1710562565,'failured'),(52,'menu','[\"--controller=Signinrecord\"]','php think menu --controller=Signinrecord','Build Successed!',1710562567,1710562567,1710562567,'successed'),(53,'menu','[\"--delete=1\",\"--controller=Signinrecord\"]','php think menu --delete=1 --controller=Signinrecord','signinrecord\nsigninrecord/add\nsigninrecord/del\nsigninrecord/edit\nsigninrecord/index\nsigninrecord/multi\nAre you sure you want to delete all those menu?  Type \'yes\' to continue: \nOperation is aborted!',1710562600,1710562600,1710562600,'failured'),(54,'menu','[\"--controller=Signinrecord\"]','php think menu --controller=Signinrecord','Build Successed!',1710562607,1710562607,1710562607,'successed'),(55,'menu','[\"--controller=Signinrecord\"]','php think menu --controller=Signinrecord','Build Successed!',1710562608,1710562608,1710562608,'successed'),(56,'crud','[\"--table=fa_signin_record\"]','php think crud --table=fa_signin_record','controller already exists!\nIf you need to rebuild again, use the parameter --force=true',1710566548,1710566548,1710566548,'failured'),(57,'crud','[\"--force=1\",\"--table=fa_signin_record\"]','php think crud --force=1 --table=fa_signin_record','Build Successed',1710566554,1710566554,1710566554,'successed'),(58,'menu','[\"--controller=signin\\/Record\"]','php think menu --controller=signin/Record','Build Successed!',1710566565,1710566565,1710566565,'successed'),(59,'menu','[\"--controller=Signinrecord\"]','php think menu --controller=Signinrecord','Build Successed!',1710566745,1710566745,1710566745,'successed'),(60,'crud','[\"--force=1\",\"--table=fa_signin_record\",\"--controller=signinrecord.php\",\"--model=signinrecord\"]','php think crud --force=1 --table=fa_signin_record --controller=signinrecord.php --model=signinrecord','Build Successed',1710566918,1710566918,1710566918,'successed'),(61,'menu','[\"--controller=Signinrecord\"]','php think menu --controller=Signinrecord','Build Successed!',1710566927,1710566927,1710566927,'successed'),(62,'crud','[\"--force=1\",\"--table=fa_signin_record\",\"--controller=signinrecord.php\"]','php think crud --force=1 --table=fa_signin_record --controller=signinrecord.php','Build Successed',1710566977,1710566977,1710566977,'successed'),(63,'menu','[\"--controller=Signinrecord\"]','php think menu --controller=Signinrecord','controller not found',1710566984,1710566984,1710566984,'successed'),(64,'menu','[\"--controller=signinrecord\\/Php\"]','php think menu --controller=signinrecord/Php','Build Successed!',1710566997,1710566997,1710566997,'successed'),(65,'crud','[\"--force=1\",\"--table=fa_article\"]','php think crud --force=1 --table=fa_article','Build Successed',1710594232,1710594232,1710594232,'successed'),(66,'menu','[\"--controller=Article\"]','php think menu --controller=Article','Build Successed!',1710594241,1710594241,1710594241,'successed'),(67,'crud','[\"--force=1\",\"--table=fa_article\"]','php think crud --force=1 --table=fa_article','Build Successed',1710594328,1710594328,1710594328,'successed'),(68,'menu','[\"--controller=Article\"]','php think menu --controller=Article','Build Successed!',1710594334,1710594334,1710594334,'successed'),(69,'crud','[\"--force=1\",\"--table=fa_article\"]','php think crud --force=1 --table=fa_article','Build Successed',1710594728,1710594728,1710594728,'successed'),(70,'menu','[\"--controller=Article\"]','php think menu --controller=Article','Build Successed!',1710594731,1710594731,1710594731,'successed'),(71,'crud','[\"--force=1\",\"--table=fa_article\"]','php think crud --force=1 --table=fa_article','Build Successed',1710594833,1710594833,1710594833,'successed'),(72,'menu','[\"--controller=Article\"]','php think menu --controller=Article','Build Successed!',1710594836,1710594836,1710594836,'successed'),(73,'crud','[\"--table=fa_admin\"]','php think crud --table=fa_admin','system table can\'t be crud',1711081079,1711081079,1711081079,'failured'),(74,'crud','[\"--table=fa_task_record\"]','php think crud --table=fa_task_record','Build Successed',1711110087,1711110087,1711110087,'successed'),(75,'crud','[\"--table=fa_taskrecord\"]','php think crud --table=fa_taskrecord','Build Successed',1711110268,1711110268,1711110268,'successed'),(76,'menu','[\"--controller=Taskrecord\"]','php think menu --controller=Taskrecord','Build Successed!',1711110279,1711110279,1711110279,'successed'),(77,'crud','[\"--force=1\",\"--table=fa_taskrecord\"]','php think crud --force=1 --table=fa_taskrecord','Build Successed',1711176825,1711176825,1711176825,'successed'),(78,'menu','[\"--controller=Taskrecord\"]','php think menu --controller=Taskrecord','Build Successed!',1711176831,1711176831,1711176832,'successed'),(79,'min','[\"--module=all\",\"--resource=all\"]','php think min --module=all --resource=all','Compress require-frontend.js\nCompress frontend.css\nCompress require-backend.js\nCompress backend.css\nBuild Successed!',1711179111,1711179111,1711179113,'successed'),(80,'api','[\"--language=zh-cn\",\"--module=api\"]','php think api --language=zh-cn --module=api','Build Successed!',1711179135,1711179135,1711179135,'successed'),(81,'crud','[\"--table=fa_questioning\"]','php think crud --table=fa_questioning','Build Successed',1716965437,1716965437,1716965437,'successed'),(82,'menu','[\"--controller=Questioning\"]','php think menu --controller=Questioning','Build Successed!',1716965448,1716965448,1716965448,'successed'),(83,'crud','[\"--table=fa_studytask\"]','php think crud --table=fa_studytask','Build Successed',1716965676,1716965676,1716965676,'successed'),(84,'menu','[\"--controller=Studytask\"]','php think menu --controller=Studytask','Build Successed!',1716965689,1716965689,1716965689,'successed'),(85,'crud','[\"--table=fa_studytaskrecord\"]','php think crud --table=fa_studytaskrecord','Build Successed',1716966109,1716966109,1716966109,'successed'),(86,'menu','[\"--controller=Studytaskrecord\"]','php think menu --controller=Studytaskrecord','Build Successed!',1716966117,1716966117,1716966117,'successed'),(87,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Build Successed',1716977902,1716977902,1716977902,'successed'),(88,'crud','[\"--force=1\",\"--table=fa_studytaskrecord\"]','php think crud --force=1 --table=fa_studytaskrecord','Build Successed',1716977934,1716977934,1716977934,'successed'),(89,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1716979311,1716979311,1716979311,'successed'),(90,'crud','[\"--force=1\",\"--table=fa_studytaskrecord\"]','php think crud --force=1 --table=fa_studytaskrecord','Build Successed',1716985469,1716985469,1716985469,'successed'),(91,'menu','[\"--controller=Studytaskrecord\"]','php think menu --controller=Studytaskrecord','Build Successed!',1716985488,1716985488,1716985488,'successed'),(92,'menu','[\"--controller=Studytaskrecord\"]','php think menu --controller=Studytaskrecord','Build Successed!',1716985489,1716985489,1716985489,'successed'),(93,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1716995754,1716995754,1716995754,'successed'),(94,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1716995754,1716995754,1716995754,'successed'),(95,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/application/admin/view/studytask/add.html): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1716997638,1716997638,1716997638,'failured'),(96,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/application/admin/view/studytask/add.html): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1716997644,1716997644,1716997644,'failured'),(97,'crud','[\"--delete=1\",\"--force=1\",\"--table=fa_studytask\"]','php think crud --delete=1 --force=1 --table=fa_studytask','/www/wwwroot/code/public/../application/admin/controller/Studytask.php\n/www/wwwroot/code/public/../application/admin/model/Studytask.php\n/www/wwwroot/code/public/../application/admin/validate/Studytask.php\n/www/wwwroot/code/application/admin/view/studytask/add.html\n/www/wwwroot/code/application/admin/view/studytask/edit.html\n/www/wwwroot/code/application/admin/view/studytask/index.html\n/www/wwwroot/code/application/admin/view/studytask/recyclebin.html\n/www/wwwroot/code/application/admin/lang/zh-cn/studytask.php\n/www/wwwroot/code/public/assets/js/backend/studytask.js\nunlink(/www/wwwroot/code/application/admin/view/studytask/add.html): Permission denied',1716997651,1716997651,1716997651,'failured'),(98,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/application/admin/view/studytask/add.html): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1716997656,1716997656,1716997656,'failured'),(99,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1716997682,1716997682,1716997682,'successed'),(100,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1716997884,1716997884,1716997884,'successed'),(101,'crud','[\"--delete=1\",\"--force=1\",\"--table=fa_taskrecord\"]','php think crud --delete=1 --force=1 --table=fa_taskrecord','/www/wwwroot/code/public/../application/admin/controller/Taskrecord.php\n/www/wwwroot/code/public/../application/admin/model/Taskrecord.php\n/www/wwwroot/code/public/../application/admin/validate/Taskrecord.php\n/www/wwwroot/code/application/admin/view/taskrecord/add.html\n/www/wwwroot/code/application/admin/view/taskrecord/edit.html\n/www/wwwroot/code/application/admin/view/taskrecord/index.html\n/www/wwwroot/code/application/admin/view/taskrecord/recyclebin.html\n/www/wwwroot/code/application/admin/lang/zh-cn/taskrecord.php\n/www/wwwroot/code/public/assets/js/backend/taskrecord.js\nDelete Successed',1720948315,1720948315,1720948315,'successed'),(102,'crud','[\"--force=1\",\"--table=fa_taskrecord\"]','php think crud --force=1 --table=fa_taskrecord','Build Successed',1720948849,1720948849,1720948849,'successed'),(103,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Build Successed',1720949352,1720949352,1720949352,'successed'),(104,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Build Successed',1720950618,1720950618,1720950618,'successed'),(105,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1720971906,1720971906,1720971906,'successed'),(106,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1721011723,1721011723,1721011723,'successed'),(107,'crud','[\"--force=1\",\"--table=fa_studytask\"]','php think crud --force=1 --table=fa_studytask','Build Successed',1721482064,1721482064,1721482064,'successed'),(108,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Build Successed',1721663420,1721663420,1721663420,'successed'),(109,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/public/../application/admin/controller/Questioning.php): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1721663927,1721663927,1721663927,'failured'),(110,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/public/../application/admin/controller/Questioning.php): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1721663941,1721663941,1721663941,'failured'),(111,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/application/admin/view/questioning/add.html): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1721663972,1721663972,1721663972,'failured'),(112,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/application/admin/view/questioning/add.html): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1721663978,1721663978,1721663978,'failured'),(113,'crud','[\"--force=1\",\"--table=fa_questioning\"]','php think crud --force=1 --table=fa_questioning','Code: 0\nLine: 1426\nMessage: file_put_contents(/www/wwwroot/code/public/assets/js/backend/questioning.js): failed to open stream: Permission denied\nFile: /www/wwwroot/code/application/admin/command/Crud.php',1721664008,1721664008,1721664008,'failured');
/*!40000 ALTER TABLE `fa_command` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_config`
--

DROP TABLE IF EXISTS `fa_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT '' COMMENT '变量名',
  `group` varchar(30) DEFAULT '' COMMENT '分组',
  `title` varchar(100) DEFAULT '' COMMENT '变量标题',
  `tip` varchar(100) DEFAULT '' COMMENT '变量描述',
  `type` varchar(30) DEFAULT '' COMMENT '类型:string,text,int,bool,array,datetime,date,file',
  `visible` varchar(255) DEFAULT '' COMMENT '可见条件',
  `value` text COMMENT '变量值',
  `content` text COMMENT '变量字典数据',
  `rule` varchar(100) DEFAULT '' COMMENT '验证规则',
  `extend` varchar(255) DEFAULT '' COMMENT '扩展属性',
  `setting` varchar(255) DEFAULT '' COMMENT '配置',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COMMENT='系统配置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_config`
--

LOCK TABLES `fa_config` WRITE;
/*!40000 ALTER TABLE `fa_config` DISABLE KEYS */;
INSERT INTO `fa_config` VALUES (1,'name','basic','Site name','请填写站点名称','string','','信息技术专题网站','','required','',NULL),(2,'secsitename','basic','Second Sitename','请填写站点副标题','select','','1','[\"Powered By 芸志信息\",\"由芸志信息开发\"]','required','',NULL),(3,'beian','basic','Beian','粤ICP备15000000号-1','string','','','','','',NULL),(4,'cdnurl','basic','Cdn url','如果全站静态资源使用第三方云储存请配置该值','string','','','','','',''),(5,'version','basic','Version','如果静态资源有变动请重新配置该值','string','','1.0.1','','required','',NULL),(6,'timezone','basic','Timezone','','string','','Asia/Shanghai','','required','',NULL),(7,'forbiddenip','basic','Forbidden ip','一行一条记录','text','','','','','',NULL),(8,'languages','basic','Languages','','array','','{\"backend\":\"zh-cn\",\"frontend\":\"zh-cn\"}','','required','',NULL),(9,'fixedpage','basic','Fixed page','请输入左侧菜单栏存在的链接','string','','dashboard','','required','',NULL),(10,'categorytype','dictionary','Category type','','array','','{\"article\":\"文章\"}','','','',NULL),(11,'configgroup','dictionary','Config group','','array','','{\"basic\":\"基础配置\",\"email\":\"邮件配置\",\"dictionary\":\"字典配置\",\"user\":\"会员配置\",\"zpqy\":\"AI设置\"}','','','',NULL),(12,'mail_type','email','Mail type','选择邮件发送方式','select','','1','[\"请选择\",\"SMTP\"]','','',''),(13,'mail_smtp_host','email','Mail smtp host','错误的配置发送邮件会导致服务器超时','string','','smtp.qq.com','','','',''),(14,'mail_smtp_port','email','Mail smtp port','(不加密默认25,SSL默认465,TLS默认587)','string','','465','','','',''),(15,'mail_smtp_user','email','Mail smtp user','（填写完整用户名）','string','','10000','','','',''),(16,'mail_smtp_pass','email','Mail smtp password','（填写您的密码或授权码）','string','','password','','','',''),(17,'mail_verify_type','email','Mail vertify type','（SMTP验证方式[推荐SSL]）','select','','2','[\"无\",\"TLS\",\"SSL\"]','','',''),(18,'mail_from','email','Mail from','','string','','10000@qq.com','','','',''),(19,'attachmentcategory','dictionary','Attachment category','','array','','{\"category1\":\"分类一\",\"category2\":\"分类二\",\"custom\":\"自定义\"}','','','',NULL),(20,'openuse','zpqy','Allow Using','请选择是否启用AI','select','','1','[\"关闭\",\"启用\"]','required','',NULL),(21,'token','zpqy','ZPQY token','请输入智普清言开发者Token','string','','','','required','',NULL);
/*!40000 ALTER TABLE `fa_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_data`
--

DROP TABLE IF EXISTS `fa_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_data`
--

LOCK TABLES `fa_data` WRITE;
/*!40000 ALTER TABLE `fa_data` DISABLE KEYS */;
INSERT INTO `fa_data` VALUES (1,1);
/*!40000 ALTER TABLE `fa_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_ems`
--

DROP TABLE IF EXISTS `fa_ems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_ems` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) DEFAULT '' COMMENT '事件',
  `email` varchar(100) DEFAULT '' COMMENT '邮箱',
  `code` varchar(10) DEFAULT '' COMMENT '验证码',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) DEFAULT '' COMMENT 'IP',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='邮箱验证码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_ems`
--

LOCK TABLES `fa_ems` WRITE;
/*!40000 ALTER TABLE `fa_ems` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_ems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_grade`
--

DROP TABLE IF EXISTS `fa_grade`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_grade` (
  `grade_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` int(11) DEFAULT NULL COMMENT '年级(example:2023)',
  `master` text COMMENT '年级组长(example:戴建平)',
  `introduce` text COMMENT '年级介绍(example:我也不知道写啥啊)',
  PRIMARY KEY (`grade_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_grade`
--

LOCK TABLES `fa_grade` WRITE;
/*!40000 ALTER TABLE `fa_grade` DISABLE KEYS */;
INSERT INTO `fa_grade` VALUES (1,2021,'未知','2021'),(3,2022,'谢科','2022'),(4,2023,'戴建平','2023'),(5,11111,'11111','11111');
/*!40000 ALTER TABLE `fa_grade` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_questioning`
--

DROP TABLE IF EXISTS `fa_questioning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_questioning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `study_taskid` int(11) NOT NULL COMMENT '学习任务ID',
  `task_record_id` int(11) NOT NULL COMMENT '提交时代码编译ID',
  `content` text NOT NULL COMMENT '提问内容',
  `reply_content` text COMMENT '回复',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_questioning`
--

LOCK TABLES `fa_questioning` WRITE;
/*!40000 ALTER TABLE `fa_questioning` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_questioning` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_signin`
--

DROP TABLE IF EXISTS `fa_signin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_signin` (
  `sign_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL COMMENT '签到名称',
  `userrange` int(11) NOT NULL COMMENT '签到班级',
  `starttime` bigint(11) NOT NULL COMMENT '开始时间',
  `endtime` bigint(11) NOT NULL COMMENT '结束时间',
  PRIMARY KEY (`sign_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_signin`
--

LOCK TABLES `fa_signin` WRITE;
/*!40000 ALTER TABLE `fa_signin` DISABLE KEYS */;
INSERT INTO `fa_signin` VALUES (7,'高一年级2301班第一周上课签到',3,1710506119,1711802119),(22,'过期の签到',1,1710563661,1710563661),(23,'还没开始の签到',1,1732982400,1735660800),(24,'program01',5,1710916291,1710918030),(25,'测试',6,1711551848,1711552208),(26,'正在进行的签到-测试组1',7,1717002704,1725114841),(27,'尚未开始的签到-测试组1',7,1727793262,1730644462),(28,'已经结束的签到-测试组1',7,1709303683,1709390083),(29,'测试2',8,1711638456,1711724856),(31,'高一年级2301班第二周上课签到',3,1715493659,1715580059),(32,'高一年级2301班第三周上课签到',3,1715666477,1715752877),(33,'高一年级2301班第四周上课签到',3,1715752891,1715839291),(34,'高一年级2301班第五周上课签到',3,1715839307,1715925707),(35,'高一年级2301班第六周上课签到',3,1715925720,1716012120),(36,'展示签到',9,1716998136,1717170936);
/*!40000 ALTER TABLE `fa_signin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_signin_record`
--

DROP TABLE IF EXISTS `fa_signin_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_signin_record` (
  `record_id` int(11) NOT NULL AUTO_INCREMENT,
  `signinid` int(11) NOT NULL,
  `userid` int(11) NOT NULL DEFAULT '0',
  `time` int(11) NOT NULL,
  `ip` text NOT NULL,
  PRIMARY KEY (`record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_signin_record`
--

LOCK TABLES `fa_signin_record` WRITE;
/*!40000 ALTER TABLE `fa_signin_record` DISABLE KEYS */;
INSERT INTO `fa_signin_record` VALUES (32,24,41,1710916812,'218.75.220.45'),(33,24,25,1710916813,'218.75.220.45'),(34,24,43,1710916824,'218.75.220.45'),(35,24,42,1710916839,'218.75.220.45'),(36,24,40,1710916839,'218.75.220.45'),(37,24,44,1710916842,'218.75.220.45'),(38,24,33,1710916843,'218.75.220.45'),(39,24,47,1710916844,'218.75.220.45'),(40,24,49,1710916855,'218.75.220.45'),(41,24,48,1710916856,'218.75.220.45'),(42,24,51,1710916857,'218.75.220.45'),(43,24,27,1710916861,'218.75.220.45'),(44,24,52,1710916865,'218.75.220.45'),(45,24,55,1710916879,'218.75.220.45'),(46,24,53,1710916883,'218.75.220.45'),(47,24,45,1710916893,'218.75.220.45'),(48,24,46,1710916899,'218.75.220.45'),(49,24,54,1710916904,'218.75.220.45'),(50,24,36,1710916922,'218.75.220.45'),(51,24,57,1710916923,'218.75.220.45'),(52,24,60,1710916982,'218.75.220.45'),(53,24,61,1710916986,'218.75.220.45'),(54,24,63,1710917022,'218.75.220.45'),(55,24,62,1710917032,'218.75.220.45'),(56,24,64,1710917101,'218.75.220.45'),(57,24,50,1710917206,'218.75.220.45'),(58,24,18,1710917833,'218.75.220.45'),(59,24,11,1711443450,'218.75.220.45'),(60,25,65,1711551894,'113.222.223.230'),(61,26,66,1711638092,'113.222.222.216'),(62,30,7,1712313947,'117.136.89.107'),(63,36,68,1716999037,'113.222.227.14'),(64,26,69,1720924622,'61.187.88.18'),(65,26,72,1721831275,'117.136.89.78');
/*!40000 ALTER TABLE `fa_signin_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_sms`
--

DROP TABLE IF EXISTS `fa_sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_sms` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `event` varchar(30) DEFAULT '' COMMENT '事件',
  `mobile` varchar(20) DEFAULT '' COMMENT '手机号',
  `code` varchar(10) DEFAULT '' COMMENT '验证码',
  `times` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '验证次数',
  `ip` varchar(30) DEFAULT '' COMMENT 'IP',
  `createtime` bigint(16) unsigned DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='短信验证码表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_sms`
--

LOCK TABLES `fa_sms` WRITE;
/*!40000 ALTER TABLE `fa_sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_studytask`
--

DROP TABLE IF EXISTS `fa_studytask`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_studytask` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL COMMENT '任务标题',
  `content` text NOT NULL COMMENT '任务内容',
  `ans` text NOT NULL COMMENT '正确答案（逐字符对比）',
  `class_id` int(11) NOT NULL COMMENT '任务所属班级',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_studytask`
--

LOCK TABLES `fa_studytask` WRITE;
/*!40000 ALTER TABLE `fa_studytask` DISABLE KEYS */;
INSERT INTO `fa_studytask` VALUES (1,'测试','<p>输出\r\n123\r\n321</p>','123321',5),(2,'养兔子','<p><span style=\"text-wrap: nowrap;\">有一对兔子，从出生后第3个月起每个月都生一对兔子，小兔子长到第3个月后每个月又生一对兔子，假如兔子都不死，问第5个月的兔子总数为多少？</span></p>','5',9),(3,'养兔子','<p><span style=\"font-size: 18px;\">有一对兔</span><span style=\"font-size: 18px;\">子，从出</span><span style=\"font-size: 18px;\">生后第3个月</span><span style=\"font-size: 18px;\">起每个月都生一对兔子，</span></p><p><span style=\"font-size: 18px;\">小兔子长到第3个月后每个月又生一对兔子，</span></p><p><span style=\"font-size: 18px;\">假如兔子都不死，问第5个月的兔子总对数为多少？</span></p><p><span style=\"font-size: 18px;\">输出格式为：</span></p><p><span style=\"font-size: 18px;\">总对数</span></p>','5',7),(4,'测试','<p>测试答案对比功能<br/></p>','cccc  !   rrr\r\ndg @@!E&\r\ng! G*@\r\n12',7);
/*!40000 ALTER TABLE `fa_studytask` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_studytaskrecord`
--

DROP TABLE IF EXISTS `fa_studytaskrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_studytaskrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL COMMENT '用户ID',
  `study_taskid` int(11) NOT NULL COMMENT '学习任务ID',
  `code_task` text NOT NULL COMMENT '编译ID',
  `done` int(1) NOT NULL COMMENT '任务是否完成',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_studytaskrecord`
--

LOCK TABLES `fa_studytaskrecord` WRITE;
/*!40000 ALTER TABLE `fa_studytaskrecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_studytaskrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_taskrecord`
--

DROP TABLE IF EXISTS `fa_taskrecord`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_taskrecord` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `taskid` int(11) NOT NULL COMMENT '任务ID',
  `code` text NOT NULL COMMENT '代码内容',
  `output` text NOT NULL COMMENT '输出结果',
  `ai` text NOT NULL COMMENT 'AI建议',
  `teacher` int(11) DEFAULT NULL COMMENT '提问ID',
  `lang` text NOT NULL COMMENT '代码语言',
  `subtime` int(11) NOT NULL COMMENT '提交时间',
  `uid` int(11) NOT NULL COMMENT '用户ID',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_taskrecord`
--

LOCK TABLES `fa_taskrecord` WRITE;
/*!40000 ALTER TABLE `fa_taskrecord` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_taskrecord` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_test`
--

DROP TABLE IF EXISTS `fa_test`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_test` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `user_id` int(10) DEFAULT '0' COMMENT '会员ID',
  `admin_id` int(10) DEFAULT '0' COMMENT '管理员ID',
  `category_id` int(10) unsigned DEFAULT '0' COMMENT '分类ID(单选)',
  `category_ids` varchar(100) DEFAULT NULL COMMENT '分类ID(多选)',
  `tags` varchar(255) DEFAULT '' COMMENT '标签',
  `week` enum('monday','tuesday','wednesday') DEFAULT NULL COMMENT '星期(单选):monday=星期一,tuesday=星期二,wednesday=星期三',
  `flag` set('hot','index','recommend') DEFAULT '' COMMENT '标志(多选):hot=热门,index=首页,recommend=推荐',
  `genderdata` enum('male','female') DEFAULT 'male' COMMENT '性别(单选):male=男,female=女',
  `hobbydata` set('music','reading','swimming') DEFAULT NULL COMMENT '爱好(多选):music=音乐,reading=读书,swimming=游泳',
  `title` varchar(100) DEFAULT '' COMMENT '标题',
  `content` text COMMENT '内容',
  `image` varchar(100) DEFAULT '' COMMENT '图片',
  `images` varchar(1500) DEFAULT '' COMMENT '图片组',
  `attachfile` varchar(100) DEFAULT '' COMMENT '附件',
  `keywords` varchar(255) DEFAULT '' COMMENT '关键字',
  `description` varchar(255) DEFAULT '' COMMENT '描述',
  `city` varchar(100) DEFAULT '' COMMENT '省市',
  `json` varchar(255) DEFAULT NULL COMMENT '配置:key=名称,value=值',
  `multiplejson` varchar(1500) DEFAULT '' COMMENT '二维数组:title=标题,intro=介绍,author=作者,age=年龄',
  `price` decimal(10,2) unsigned DEFAULT '0.00' COMMENT '价格',
  `views` int(10) unsigned DEFAULT '0' COMMENT '点击',
  `workrange` varchar(100) DEFAULT '' COMMENT '时间区间',
  `startdate` date DEFAULT NULL COMMENT '开始日期',
  `activitytime` datetime DEFAULT NULL COMMENT '活动时间(datetime)',
  `year` year(4) DEFAULT NULL COMMENT '年',
  `times` time DEFAULT NULL COMMENT '时间',
  `refreshtime` bigint(16) DEFAULT NULL COMMENT '刷新时间',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `deletetime` bigint(16) DEFAULT NULL COMMENT '删除时间',
  `weigh` int(10) DEFAULT '0' COMMENT '权重',
  `switch` tinyint(1) DEFAULT '0' COMMENT '开关',
  `status` enum('normal','hidden') DEFAULT 'normal' COMMENT '状态',
  `state` enum('0','1','2') DEFAULT '1' COMMENT '状态值:0=禁用,1=正常,2=推荐',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='测试表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_test`
--

LOCK TABLES `fa_test` WRITE;
/*!40000 ALTER TABLE `fa_test` DISABLE KEYS */;
INSERT INTO `fa_test` VALUES (1,1,1,12,'12,13','互联网,计算机','monday','hot,index','male','music,reading','我是一篇测试文章','<p>我是测试内容</p>','/assets/img/avatar.png','/assets/img/avatar.png,/assets/img/qrcode.png','/assets/img/avatar.png','关键字','我是一篇测试文章描述，内容过多时将自动隐藏','广西壮族自治区/百色市/平果县','{\"a\":\"1\",\"b\":\"2\"}','[{\"title\":\"标题一\",\"intro\":\"介绍一\",\"author\":\"小明\",\"age\":\"21\"}]',0.00,0,'2020-10-01 00:00:00 - 2021-10-31 23:59:59','2017-07-10','2017-07-10 18:24:45',2017,'18:24:45',1491635035,1491635035,1491635035,NULL,0,1,'normal','1');
/*!40000 ALTER TABLE `fa_test` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user`
--

DROP TABLE IF EXISTS `fa_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `group_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '组别ID',
  `class` text NOT NULL,
  `username` varchar(32) DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) DEFAULT '' COMMENT '昵称',
  `grade` int(11) DEFAULT NULL COMMENT '年级',
  `password` varchar(32) DEFAULT '' COMMENT '密码',
  `salt` varchar(30) DEFAULT '' COMMENT '密码盐',
  `email` varchar(100) DEFAULT '' COMMENT '电子邮箱',
  `mobile` varchar(11) DEFAULT '' COMMENT '手机号',
  `avatar` varchar(255) DEFAULT '' COMMENT '头像',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '等级',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `bio` varchar(100) DEFAULT '' COMMENT '格言',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '余额',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '积分',
  `successions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '连续登录天数',
  `maxsuccessions` int(10) unsigned NOT NULL DEFAULT '1' COMMENT '最大连续登录天数',
  `prevtime` bigint(16) DEFAULT NULL COMMENT '上次登录时间',
  `logintime` bigint(16) DEFAULT NULL COMMENT '登录时间',
  `loginip` varchar(50) DEFAULT '' COMMENT '登录IP',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `joinip` varchar(50) DEFAULT '' COMMENT '加入IP',
  `jointime` bigint(16) DEFAULT NULL COMMENT '加入时间',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `token` varchar(50) DEFAULT '' COMMENT 'Token',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  `verification` varchar(255) DEFAULT '' COMMENT '验证',
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `email` (`email`),
  KEY `mobile` (`mobile`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COMMENT='会员表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user`
--

LOCK TABLES `fa_user` WRITE;
/*!40000 ALTER TABLE `fa_user` DISABLE KEYS */;
INSERT INTO `fa_user` VALUES (1,1,'','admin','admin',NULL,'472be8ff238ce31bad99be9cd8d24d4e','4fc754','admin@163.com','13888888888','http://wuliji01.xiaozmax.top:6789/assets/img/avatar.png',0,0,'2017-04-08','',0.00,0,1,1,1491635035,1491635035,'127.0.0.1',0,'127.0.0.1',1491635035,0,1491635035,'','normal','');
/*!40000 ALTER TABLE `fa_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_group`
--

DROP TABLE IF EXISTS `fa_user_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT '' COMMENT '组名',
  `rules` text COMMENT '权限节点',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `status` enum('normal','hidden') DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COMMENT='会员组表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_group`
--

LOCK TABLES `fa_user_group` WRITE;
/*!40000 ALTER TABLE `fa_user_group` DISABLE KEYS */;
INSERT INTO `fa_user_group` VALUES (1,'默认组','1,2,3,4,5,6,7,8,9,10,11,12',1491635035,1491635035,'normal'),(2,'学生','1,3,5,6,7,8',1699668771,1699668771,'normal'),(3,'2301','1,3,5,6,7,8',0,0,'normal'),(4,'2302','2,4,11,10,9,12,1,3,7,6,5,8',1710383116,1710383116,'normal'),(5,'2310','1,3,7,6,5,8',1710916048,1710916048,'normal'),(6,'测试','2,4,11,10,9,12,1,3,7,6,5,8',1711551402,1711551402,'normal'),(7,'测试组1','2,4,11,10,9,12,1,3,7,6,5,8',1711636418,1711636418,'normal'),(8,'测试2','2,4,11,10,9,12,1,3,7,6,5,8',1711638318,1711638318,'normal'),(9,'国赛-视频演示','2,4,11,10,9,12,1,3,7,6,5,8',1716996548,1716996548,'normal');
/*!40000 ALTER TABLE `fa_user_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_money_log`
--

DROP TABLE IF EXISTS `fa_user_money_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_money_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `money` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更余额',
  `before` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更前余额',
  `after` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '变更后余额',
  `memo` varchar(255) DEFAULT '' COMMENT '备注',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员余额变动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_money_log`
--

LOCK TABLES `fa_user_money_log` WRITE;
/*!40000 ALTER TABLE `fa_user_money_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_user_money_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_rule`
--

DROP TABLE IF EXISTS `fa_user_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) DEFAULT NULL COMMENT '父ID',
  `name` varchar(50) DEFAULT NULL COMMENT '名称',
  `title` varchar(50) DEFAULT '' COMMENT '标题',
  `remark` varchar(100) DEFAULT NULL COMMENT '备注',
  `ismenu` tinyint(1) DEFAULT NULL COMMENT '是否菜单',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) DEFAULT '0' COMMENT '权重',
  `status` enum('normal','hidden') DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='会员规则表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_rule`
--

LOCK TABLES `fa_user_rule` WRITE;
/*!40000 ALTER TABLE `fa_user_rule` DISABLE KEYS */;
INSERT INTO `fa_user_rule` VALUES (1,0,'index','Frontend','',1,1491635035,1491635035,1,'normal'),(2,0,'api','API Interface','',1,1491635035,1491635035,2,'normal'),(3,1,'user','User Module','',1,1491635035,1491635035,12,'normal'),(4,2,'user','User Module','',1,1491635035,1491635035,11,'normal'),(5,3,'index/user/login','Login','',0,1491635035,1491635035,5,'normal'),(6,3,'index/user/register','Register','',0,1491635035,1491635035,7,'normal'),(7,3,'index/user/index','User Center','',0,1491635035,1491635035,9,'normal'),(8,3,'index/user/profile','Profile','',0,1491635035,1491635035,4,'normal'),(9,4,'api/user/login','Login','',0,1491635035,1491635035,6,'normal'),(10,4,'api/user/register','Register','',0,1491635035,1491635035,8,'normal'),(11,4,'api/user/index','User Center','',0,1491635035,1491635035,10,'normal'),(12,4,'api/user/profile','Profile','',0,1491635035,1491635035,3,'normal');
/*!40000 ALTER TABLE `fa_user_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_score_log`
--

DROP TABLE IF EXISTS `fa_user_score_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_score_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `score` int(10) NOT NULL DEFAULT '0' COMMENT '变更积分',
  `before` int(10) NOT NULL DEFAULT '0' COMMENT '变更前积分',
  `after` int(10) NOT NULL DEFAULT '0' COMMENT '变更后积分',
  `memo` varchar(255) DEFAULT '' COMMENT '备注',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员积分变动表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_score_log`
--

LOCK TABLES `fa_user_score_log` WRITE;
/*!40000 ALTER TABLE `fa_user_score_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_user_score_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_user_token`
--

DROP TABLE IF EXISTS `fa_user_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_user_token` (
  `token` varchar(50) NOT NULL COMMENT 'Token',
  `user_id` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '会员ID',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `expiretime` bigint(16) DEFAULT NULL COMMENT '过期时间',
  PRIMARY KEY (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会员Token表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_user_token`
--

LOCK TABLES `fa_user_token` WRITE;
/*!40000 ALTER TABLE `fa_user_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_user_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_version`
--

DROP TABLE IF EXISTS `fa_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_version` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `oldversion` varchar(30) DEFAULT '' COMMENT '旧版本号',
  `newversion` varchar(30) DEFAULT '' COMMENT '新版本号',
  `packagesize` varchar(30) DEFAULT '' COMMENT '包大小',
  `content` varchar(500) DEFAULT '' COMMENT '升级内容',
  `downloadurl` varchar(255) DEFAULT '' COMMENT '下载地址',
  `enforce` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '强制更新',
  `createtime` bigint(16) DEFAULT NULL COMMENT '创建时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) DEFAULT '' COMMENT '状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='版本表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_version`
--

LOCK TABLES `fa_version` WRITE;
/*!40000 ALTER TABLE `fa_version` DISABLE KEYS */;
INSERT INTO `fa_version` VALUES (1,'1.1.1,2','1.2.1','20M','更新内容','https://www.example.com',1,1520425318,0,0,'normal');
/*!40000 ALTER TABLE `fa_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_xunsearch_fields`
--

DROP TABLE IF EXISTS `fa_xunsearch_fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_xunsearch_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) DEFAULT '0' COMMENT '项目ID',
  `name` varchar(50) DEFAULT '' COMMENT '字段名称',
  `title` varchar(100) DEFAULT '' COMMENT '字段标题',
  `type` enum('string','numeric','date','id','title','body') DEFAULT NULL COMMENT '类型',
  `index` enum('none','self','mixed','both') DEFAULT NULL COMMENT '索引方式',
  `tokenizer` varchar(100) DEFAULT NULL COMMENT '分词器',
  `cutlen` int(10) unsigned DEFAULT '0' COMMENT '摘要结果截取长度',
  `weight` int(10) unsigned DEFAULT '1' COMMENT '混合区检索时的概率权重',
  `phrase` enum('yes','no') DEFAULT 'no' COMMENT '是否支持精确检索',
  `non_bool` enum('yes','no') DEFAULT 'no' COMMENT '强制指定是否为布尔索引',
  `extra` tinyint(1) unsigned DEFAULT '1' COMMENT '是否附属字段',
  `sortable` tinyint(1) DEFAULT '1' COMMENT '是否允许排序',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `status` enum('normal','hidden') DEFAULT 'normal' COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Xunsearch字段列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_xunsearch_fields`
--

LOCK TABLES `fa_xunsearch_fields` WRITE;
/*!40000 ALTER TABLE `fa_xunsearch_fields` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_xunsearch_fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fa_xunsearch_project`
--

DROP TABLE IF EXISTS `fa_xunsearch_project`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fa_xunsearch_project` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT '' COMMENT '项目名称',
  `title` varchar(100) DEFAULT '' COMMENT '项目标题',
  `charset` varchar(50) DEFAULT '' COMMENT '编码',
  `serverindex` varchar(100) DEFAULT NULL COMMENT '索引服务端',
  `serversearch` varchar(100) DEFAULT NULL COMMENT '搜索服务端',
  `logo` varchar(100) DEFAULT '' COMMENT 'Logo',
  `indextpl` varchar(100) DEFAULT '' COMMENT '搜索页模板',
  `listtpl` varchar(100) DEFAULT '' COMMENT '列表页模板',
  `isaddon` tinyint(1) unsigned DEFAULT '1' COMMENT '是否插件',
  `isfuzzy` tinyint(1) unsigned DEFAULT '1' COMMENT '是否模糊搜索',
  `issynonyms` tinyint(1) unsigned DEFAULT '1' COMMENT '是否同义词搜索',
  `isfrontend` tinyint(1) unsigned DEFAULT '1' COMMENT '是否开启前台搜索',
  `isindexhotwords` tinyint(1) unsigned DEFAULT '1' COMMENT '是否首页热门搜索',
  `ishotwords` tinyint(1) unsigned DEFAULT '0' COMMENT '是否列表页热门搜索',
  `isrelatedwords` tinyint(1) unsigned DEFAULT '1' COMMENT '是否列表页相关搜索',
  `pagesize` int(10) unsigned DEFAULT '10' COMMENT '搜索分页大小',
  `createtime` bigint(16) DEFAULT NULL COMMENT '添加时间',
  `updatetime` bigint(16) DEFAULT NULL COMMENT '更新时间',
  `status` enum('normal','hidden') DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='Xunsearch配置表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fa_xunsearch_project`
--

LOCK TABLES `fa_xunsearch_project` WRITE;
/*!40000 ALTER TABLE `fa_xunsearch_project` DISABLE KEYS */;
/*!40000 ALTER TABLE `fa_xunsearch_project` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'yunzhi-study'
--

--
-- Dumping routines for database 'yunzhi-study'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-27 10:36:44
